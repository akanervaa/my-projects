#ifndef VIEWCONTROLLER_H
#define VIEWCONTROLLER_H

#include <QObject>
#include <QtCharts>
#include "energydatabank.hh"
#include "weatherdatabank.hh"

using namespace QtCharts;

class ViewController:public QObject
{
    Q_OBJECT
   Q_PROPERTY(QList<QPointF> weathervalues READ getweathervalues NOTIFY weathervaluesChanged)
    Q_PROPERTY(QList<QPointF> energyvalues READ getenergyvalues NOTIFY energyvaluesChanged)
    //axisvalues = [X axis min, x axis min, y axis min, y axis max]
    Q_PROPERTY(QVector<qreal> axisvalues READ getaxisvalues)//WRITE setaxisvalues, but this doesnt accept proper function arguments
    Q_PROPERTY(QVector<qreal> axisvaluesweather READ getaxisvaluesweather)

    Q_PROPERTY(bool deletadata READ getdeletedata)
    Q_PROPERTY(bool fetchEnergy READ fetchenergy)
    Q_PROPERTY(bool fetchWeather READ fetchweather)
    Q_PROPERTY(bool loadpreference READ loadpreference)

public:
    explicit ViewController(QObject *parent = nullptr);
    /**
     * @brief getweathervalues;fetches data from weatherdatabank according to inner variables
     * @return data from weatherdatabank
     */
    QList<QPointF> getweathervalues();
    /**
     * @brief getenergyvalues;fetches data from energydatabank according to inner variables
     * @return data from energydatabank
     */
    QList<QPointF> getenergyvalues();
    /**
     * @brief getaxisvalues; axisvalues according energybank data
     * @return [xmin, xmax, ymin, ymax]
     */
    QVector<qreal> getaxisvalues();
    /**
     * @brief getaxisvalues; axisvalues according weatherbank data
     * @return [xmin, xmax, ymin, ymax]
     */
    QVector<qreal> getaxisvaluesweather();
    /**
     * @brief calcaxisvalues; calculates min and max for x and y from param data
     * @param data
     * @return [xmin, xmax, ymin, ymax]
     */
    QVector<qreal> calcaxisvalues(QList<QPointF> data);

    /**
     * @brief getdeletedata; deletes data from weather and energydatabanks
     * @return if succesfull
     */
    bool getdeletedata();
    /**
     * @brief fetchenergy; fetches energydata according to set parameters
     * @return
     */
    bool fetchenergy();
    /**
     * @brief fetchweather; fetches weatherdata according to set parameters
     * @return
     */
    bool fetchweather();
    /**
     * @brief loadpreference; loads and sets up preferences for drawing
     * @return
     */
    bool loadpreference();


signals:
    void energyvaluesChanged();
    void weathervaluesChanged();


public slots:
    /**
     * @brief setEnergyType; sets wanted energy type for later use
     * @param value; type that is wanted
     */
    void setEnergyType(QString value);

    /**
     * @brief setWeatherType; sets wanted weather type for later use
     * @param weatherandcity; type that is wanted
     */
    void setWeatherType(QVector<QString> weatherandcity);
    /**
     * @brief setDate; sets timeframe for later use
     * @param dates; [startdate, enddate]
     * @param times; [starttimeoftheday endtimeoftheday]
     */
    void setDate(QVector<QDate> dates, QVector<QTime> times);
    /**
     * @brief getsaveEnergy; saves energydata to external file
     * @param parameterstosave, currently active parameters from QML
     */
    void saveLocal(QVector<QString> parameterstosave);
    /**
     * @brief loadLocal; loads data from external file
     * @param parameterstoload,currently active parameters from QML
     */
    void loadLocal(QVector<QString> parameterstoload);
    /**
      * @brief savepreference, saves preferences to a file
      * @param preferences
      */
     void savepreference(QVector<QString> preferences);

private:
    EnergyDataBank* energyDataBank_;
    QString currentcity_;
    WeatherDataBank* weatherDataBank_;


    ApiType energytodraw_;
    ApiType weathertodraw_;

    QVector<qreal> axisvalues_;

    QVector<QDate> dates_;
    QVector<QTime> times_;

};

#endif // VIEWCONTROLLER_H
