#include <QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>            // needed for setContextProperty
#include <buttoncontroller.hh>
#include "energydatabank.hh"
#include "weatherdatabank.hh"
#include "viewcontroller.h"
#include "QObject"
int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QApplication app(argc, argv);

    QQmlApplicationEngine engine;

    // sharing the created ViewController object to the QML with setContextProperty
    ViewController viewController;
    ButtonController buttonController;
    engine.rootContext()->setContextProperty("viewController", &viewController);
    engine.rootContext()->setContextProperty("ButtonController", &buttonController);
    QObject::connect(&buttonController, &ButtonController::energyTypeChanged, &viewController, &ViewController::setEnergyType);
    QObject::connect(&buttonController, &ButtonController::WeatherorCityChanged, &viewController, &ViewController::setWeatherType);
    QObject::connect(&buttonController, &ButtonController::dateSignal, &viewController, &ViewController::setDate);
    QObject::connect(&buttonController, &ButtonController::savesignal, &viewController, &ViewController::saveLocal);
    QObject::connect(&buttonController, &ButtonController::loadsignal, &viewController, &ViewController::loadLocal);
    QObject::connect(&buttonController, &ButtonController::preferencetosavesignal, &viewController, &ViewController::savepreference);
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    // --- testausta varten ---
//    EnergyDataBank e;
//    e.getDataBetween(ApiType::CONSUMPTION_FIN, QDate(2021,3,9), QDate(2021,3,9), QTime(9,40,0), QTime(10,40,0));
//    e.printDatabase();
//    e.getDataForChart();


//    WeatherDataBank w;
//    w.getDataByLocation(ApiType::TEMPERATURE_PREDICTION, QDate(2021,3,9), QDate(2021,3,9), QTime(9,40,0), QTime(10,40,0), "Tampere");
    // --- ---
    return app.exec();
}
