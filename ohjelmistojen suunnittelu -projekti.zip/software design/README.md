Our weather and electricity data visualization app.

Final
current design document (OHJUS-midterm-document.pdf) can be found in the repository.

GUIDE TO USER

COMMON MISTAKES IN USE

Fetching multiple timeframes for one type of data (for example temperature of Turku, or hydro production of Finland) WILL result in inaccuracies!
Always "delete all fetched data" before fetching the same type of data again.

X-axes are labeled when selecting a timeframe. Using an x-axis that doesnt have the current timeframe applied to it will label the x-axis wrongly while drawing

FUNCTIONALITIES

set timeframe: select appropiate timeframe with spinboxes, use "apply"-button to confirm 

fetch data: select appropiate type of data (and write the town if using weather-data). Press a "Fetch"-button. Data will be fetched in the background to memory. A timeframe must be set before fetching.
 
Draw data: Press a "draw" -button to draw data. Drawing is done according to type of data selected (and the town written for weather-data). Fetching must be done before drawing. THE SET TIMEFRAME HAS NO EFFECT ON DRAWING DATA. All data is drawn one datapoint per hour. If the data has more datapoints, an average is calculated from the points.

Save to local: select datatypes to save from comboboxes, and a town you want weather data to be saved from. Fetch data. Save these two datas to a local file by pressing "save recent to local"
Load from local: Select datatypes to load from comboboxes, and a town you want weather data from. Press "Load Local Data". DO NOT FETCH. Data is now ready to be drawn using draw buttons. 

Clear drawings: deletes everything drawn

Delete all fetched data: deletes all data from memory

Save recent to local: Saves the fetched data indicated by the selected types in comboboxes. Saving is done to a local file.

Load Local data: Loads data from local file. 

Set axes: Select wanted x and y axes from comboboxes on the left. For y-axis you can either choose to either fit it automatically to data or set it manually using textinputs below comboboxes. Next drawings will be drawn to those new axis. Set timeframe will be shown for x-axis. The most recent type of data to use the y-axis on will be shown on the y-axis.

datapoint value: Pressing a datapoint will show its value in bottom left corner.

Saving preference: Press save preferences to save current combobox types. Town and timeframe are not saved!
Load preferences: press load preferences to load preferences. This fetches the data using saved parameters. Remember to set a proper timeframe before loading. Use "Draw Energy Data" to draw this preference data. Remember to set energycombobox to the preference for drawing to work. 









