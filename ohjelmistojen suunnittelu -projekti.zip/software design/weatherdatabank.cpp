#include "weatherdatabank.hh"

WeatherDataBank::WeatherDataBank():
    networkHandler_(new NetworkHandler)
{
    connect(networkHandler_, &NetworkHandler::currentContentChanged, this, &WeatherDataBank::getRequestReady);
}

WeatherDataBank::~WeatherDataBank()
{
    delete networkHandler_;
}

void WeatherDataBank::getData(ApiType type, QString startTime, QString endTime)
{

}

void WeatherDataBank::getDataByLocation(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime, QString location)
{
    // http://opendata.fmi.fi/wfs?request=getFeature&version=2.0.0
    // &storedquery_id=fmi::forecast::harmonie::surface::point::multipointcoverage
    // &place=Tampere&parameters=Temperature

    //    https://opendata.fmi.fi/wfs?request=getFeature&version=2.0.0
    //    &storedquery_id=fmi::observations::weather::hourly::timevaluepair
    //    &place=Tampere&parameters=TA_PT1H_AVG

    // miten forecast toimii
    currentType_ = type;
    currentLocation_ = location;
    QString url = fmiUrl_;
    if( type == ApiType::WIND_PREDICTION or type == ApiType::TEMPERATURE_PREDICTION ){
        url += forecast_storedquery_id;
    } else if( type == ApiType::WINDSPEED or type == ApiType::CLOUDINESS
               or type == ApiType::TEMPERATURE ){
        url += observation_storedquery_id;
    }  else {
        qDebug() << "Error in WeatherDataBank::getDataByLocation: type not found in weather data";
        return;
    }
    QString startTimeString = xmlStringProcessor_->buildTimeQString(StartDate, StartTime);
    QString endTimeString = xmlStringProcessor_->buildTimeQString(EndDate, EndTime);
    url += "&place=" + location + "&timestep=" + timestep_ +
            "&starttime=" + startTimeString + "&endtime=" + endTimeString;
    std::map<ApiType, QString>::iterator it = ApiTypeUrlParams.find(type);
    // it->second cannot be end because of earlier check
    url +="&parameters="+ it->second;
    std::cout << url.toStdString() << std::endl;
    networkHandler_->requestUrl(url);
}



void WeatherDataBank::getDataBetween(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime)
{

}

void WeatherDataBank::getDataByLocationWithSplitted(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime, QString location)
{
    qint64 limit = 5;

    if (StartDate.daysTo(EndDate) <= limit) {
        stillSearching = false;
        getDataByLocation(type, StartDate, EndDate, StartTime, EndTime, location);
        return;
    }
    else {
        current_StartTime.setHMS(0,0,0);
        current_EndTime = EndTime;
        current_StartDate = StartDate.addDays(limit);
        current_EndDate = EndDate;
        stillSearching = true;
        getDataByLocation(type, StartDate, StartDate.addDays(limit), StartTime, QTime(0,0,0), location);
        return;
    }
}

void WeatherDataBank::saveCurrentSelection()
{

}

void WeatherDataBank::saveHistoryData()
{

}

void WeatherDataBank::printDatabase()
{
    // If exist
    if (dataForEachApi_.find(currentLocation_) != dataForEachApi_.end()) {
        if (dataForEachApi_.at(currentLocation_).find(currentType_) != dataForEachApi_.at(currentLocation_).end()) {

            for (auto d : dataForEachApi_.at(currentLocation_).at(currentType_)) {
                for (auto t : d.second) {
                    std::cout << d.first.day() <<
                                 " " <<
                                 t.first.hour() <<
                                 " " <<
                                 t.second <<
                                 std::endl;
                }
            }
        }
    }
}

chartData WeatherDataBank::getDataForChart(ApiType type, QString location)
{
    chartData tempData;
    int j = 0;

    // If exist
    if (dataForEachApi_.find(location) != dataForEachApi_.end()) {
        if (dataForEachApi_.at(location).find(type) != dataForEachApi_.at(location).end()) {
            int lengthofday = 24;
            for (auto d : dataForEachApi_.at(location).at(type)) {

                for (auto t : d.second) {
                    tempData.insert(j, QPointF(j/static_cast<double>(lengthofday), t.second));
                    j++;
                }
            }
        }
    }

    for (auto t : tempData) {
        std::cout << t.x() << " " << t.y() << std::endl;
    }

    std::cout << "ollaan DataforChartissa" << std::endl;

    return tempData;
}

void WeatherDataBank::convertData(QString content, ApiType type, QString location)
{
    QXmlStreamReader reader(content);

    QDate date;
    QTime time;

    QString endPart = ApiTypeUrlParams.at(type);
    QString startPart;
    if (type == ApiType::WIND_PREDICTION or type == ApiType::TEMPERATURE_PREDICTION) {
        startPart = "mts-1-1-";
    }
    else {
        startPart = "obs-obs-1-1-";
    }

    if (reader.readNextStartElement()) {
        if (reader.name() == "FeatureCollection"){
            while(reader.readNextStartElement()){
                if(reader.name() == "member"){
                    while(reader.readNextStartElement()){
                        if(reader.name() == "PointTimeSeriesObservation"){
                            while (reader.readNextStartElement()) {
                                if (reader.name() == "result") {
                                    while (reader.readNextStartElement()) {
                                        if (reader.name() == "MeasurementTimeseries" and reader.attributes().at(0).value() == startPart + endPart) {
                                            while (reader.readNextStartElement()) {
                                                if (reader.name() == "point") {
                                                    while (reader.readNextStartElement()) {
                                                        if (reader.name() == "MeasurementTVP") {
                                                            while (reader.readNextStartElement()) {

                                                                if (reader.name() == "time") {
                                                                    QString date_time = reader.readElementText();
                                                                    auto date_time_parts = xmlStringProcessor_->split(date_time.toStdString(), 'T');
                                                                    date = xmlStringProcessor_->convertToDate(date_time_parts.at(0));
                                                                    time = xmlStringProcessor_->convertToTime(date_time_parts.at(1));

                                                                    //std::cout << date_time.toStdString() << std::endl;

                                                                }
                                                                else if (reader.name() == "value") {
                                                                    QString value_string = reader.readElementText();
                                                                    double value = 0;
                                                                    if (value_string == "NaN") {
                                                                        std::cout << "EEII AARRVVOOAA" << std::endl;
                                                                    }
                                                                    else {
                                                                        value = value_string.toDouble();
                                                                    }

                                                                    //std::cout << value_string.toStdString() << std::endl;

                                                                    saveToDatabase(date, time, value, type, location);
                                                                }

                                                                else {
                                                                    reader.skipCurrentElement();
                                                                }
                                                            }
                                                        }
                                                        else {
                                                            reader.skipCurrentElement();
                                                        }
                                                    }
                                                }
                                                else {
                                                    reader.skipCurrentElement();
                                                }
                                            }
                                        }
                                        else {
                                            reader.skipCurrentElement();
                                        }
                                    }
                                }
                                else {
                                    reader.skipCurrentElement();
                                }
                            }
                        }
                        else {
                            reader.skipCurrentElement();
                        }
                    }
                }
                else {
                    reader.skipCurrentElement();
                }
            }
        }
        else {
            reader.raiseError(QObject::tr("Incorrect file"));
        }
    }
    //getDataForChart(type, location);

    if (stillSearching) {
        getDataByLocationWithSplitted(currentType_, current_StartDate, current_EndDate, current_StartTime, current_EndTime, currentLocation_);
    }
    else {
        // saatiin päätökseen haku
        printDatabase();
    }
}

bool WeatherDataBank::saveDataSelection(ApiType type ,QString location)
{
    // open file
    QFile saveFile(selectionDataFilepath_);
    if (!saveFile.exists()) {
        qWarning() << "SaveDataSelection: save file doesn't exist";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
        return false;
    }
    QString filecontent = saveFile.readAll();
//    QString filecontent = openAndReadFile(selectionDataFilepath_);
    // parse json content
    if( filecontent != "" or filecontent != "null" ){
        j = json::parse(filecontent.toStdString());
    } else {
        qWarning() << "empty json file";
        return false;
    }
    int ti = type;
    std::string t = std::to_string(ti);
    json emptyj;
    j["fmi"][location.toStdString()][t] = emptyj;
    // loop through dataForEachApi
    timeBasedData_forEachApi::iterator findit = dataForEachApi_.find(location);
    if( findit != dataForEachApi_.end() ) {
        //type
        std::map<ApiType, std::map<QDate, std::map<QTime, double>>> locdata = dataForEachApi_.at(location);
        for( std::pair<ApiType, std::map<QDate, std::map<QTime, double>>> apidata : locdata ){
            if( apidata.first == type ) {
                for( std::pair<QDate, std::map<QTime, double>> datedata : apidata.second ) {
                    // datestring for json
                    std::string datestring =
                            std::to_string(datedata.first.year()) +
                            "-" +
                            xmlStringProcessor_->convertToString(datedata.first.month()) +
                            "-" +
                            xmlStringProcessor_->convertToString(datedata.first.day());
                    for( std::pair<QTime, double> timevalpair : datedata.second ){
                        //timestring for json
                        std::string timestring =
                                xmlStringProcessor_->convertToString(timevalpair.first.hour()) +
                                ":" +
                                xmlStringProcessor_->convertToString(timevalpair.first.minute()) +
                                ":" +
                                xmlStringProcessor_->convertToString(timevalpair.first.second()) +
                                "+00Z";
                        // add data to json
                        j["fmi"][location.toStdString()][t][datestring][timestring] = timevalpair.second;
                    }
                }
            }
        }
    }

    //    std::cout << j.dump(4);
    // empty current file
    saveFile.resize(0);
    // write new json content to file
    QTextStream outStream(&saveFile);
    outStream << QString::fromStdString(j.dump(4));
    saveFile.close();
    return true;
}

bool WeatherDataBank::readFromFile(ApiType type, QString location)
{
    QString filecontent = openAndReadFile(selectionDataFilepath_);
    // file content into nlohmann::json
    if( filecontent != "" or filecontent != "null" ){
        j = json::parse(filecontent.toStdString());
    } else{
        qWarning() << "in readFromFile: file content empty or null";
    }
    // for storing the data
    int ti = type;
    std::string t = std::to_string(ti);
    // parse json content into timeBasedData
    for (json::iterator fmi = j.begin(); fmi != j.end(); ++fmi){
        if( fmi.key() == "fmi" ) {
            json locj = fmi.value();
            qDebug() << QString::fromStdString(fmi.key());
            for( json::iterator loc = locj.begin(); loc != locj.end(); ++loc ){
                if( loc.key() == location.toStdString() ){
                    qDebug() << QString::fromStdString(loc.key());
                    json apij = loc.value();
                    for( json::iterator api = apij.begin(); api != apij.end(); ++api ){
                        if( t == api.key() ){
                            json datej = api.value();
                            qDebug() << QString::fromStdString(api.key());
                            for( json::iterator date = datej.begin(); date != datej.end(); ++date ){
                                json timej = date.value();
                                for( json::iterator time = timej.begin(); time != timej.end(); ++time ){
                                    qDebug() << QString::fromStdString(time.key());
                                    QDate d = xmlStringProcessor_->convertToDate(date.key());
                                    QTime t = xmlStringProcessor_->convertToTime(time.key());
                                    saveToDatabase(d, t,time.value(),type, location);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    qDebug() << "readFromFile database:";
    printDatabase();
    return true;
}

void WeatherDataBank::savePreferences(std::vector<ApiType> types)
{
    // open file
    QFile saveFile(selectionDataFilepath_);
    if (!saveFile.exists()) {
        qWarning() << "savePreferences: save file doesn't exist";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
    }
    QString filecontent = saveFile.readAll();
    j = json::parse(filecontent.toStdString());
    j["fmi"]["preferences"] = {};
    for( ApiType t : types ){
        int ti = t;
        std::string ts = std::to_string(ti);
        j["fmi"]["preferences"].push_back(ts);
    }
    // empty current file
    // write new json content to file
    saveFile.resize(0);
    QTextStream outStream(&saveFile);
    outStream << QString::fromStdString(j.dump(4));
    saveFile.close();
}

std::vector<ApiType> WeatherDataBank::readPreferences()
{
    QString content = openAndReadFile(selectionDataFilepath_);
    j = json::parse(content.toStdString());
    std::vector<ApiType> v;
    std::vector<std::string> sv = j["fmi"]["preferences"];
    for (std::string s : sv){
        int i = stoi(s);
        ApiType a = static_cast<ApiType>(i);
        v.push_back(a);
        qDebug() << i;
    }
    return v;
}

QString WeatherDataBank::openAndReadFile(QString fileLocation)
{
    // open file
    QFile saveFile(fileLocation);
    if (!saveFile.exists()) {
        qWarning() << "openAndReadFile: file doesn't exist: " << selectionDataFilepath_;
        return "";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
        return "";
    }
    QString content = saveFile.readAll();
    saveFile.close();
    return content;
}

void WeatherDataBank::saveToDatabase(QDate date, QTime time, double value, ApiType type, QString location)
{
    if (dataForEachApi_.find(location) == dataForEachApi_.end()) {
        dataForEachApi_[location];
    }

    if (dataForEachApi_.at(location).find(type) == dataForEachApi_.at(location).end()) {
        dataForEachApi_.at(location)[type];
    }

    if (dataForEachApi_.at(location).at(type).find(date) == dataForEachApi_.at(location).at(type).end()) {
        dataForEachApi_.at(location).at(type)[date][time];
    }

    if (dataForEachApi_.at(location).at(type).at(date).find(time) == dataForEachApi_.at(location).at(type).at(date).end()) {
        dataForEachApi_.at(location).at(type).at(date)[time];
    }

    // Store to database
    dataForEachApi_.at(location).at(type).at(date).at(time) = value;
}

void WeatherDataBank::setTimestep(int tstep)
{
    timestep_ = tstep;
}

void WeatherDataBank::getRequestReady()
{
    QString content = networkHandler_->getCurrentContent();
    convertData(content, currentType_, currentLocation_);
//    saveDataSelection(currentType_, currentLocation_);
//    readFromFile(currentType_, currentLocation_);
    std::vector<ApiType> a;
    a.push_back(ApiType::WINDSPEED);
    savePreferences(a);
    std::vector<ApiType> b = readPreferences();
    qDebug() << "b";
    qDebug() << b[0];
}

