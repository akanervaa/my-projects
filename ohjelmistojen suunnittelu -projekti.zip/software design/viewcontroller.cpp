#include "viewcontroller.h"
#include <unistd.h>
ViewController::ViewController(QObject *parent):
energyDataBank_(new EnergyDataBank()),
weatherDataBank_(new WeatherDataBank()),
dates_({QDate(2021,3,17),QDate(2021,3,17)}),
times_({QTime(8,00,0),QTime(10,00,0)})
{

}

QList<QPointF> ViewController::getenergyvalues()
{
    QList<QPointF> series;
    series = energyDataBank_->getDataForChart(energytodraw_);
    return series;
}

QVector<qreal> ViewController::getaxisvalues()
{
    chartData data = getenergyvalues();
    return calcaxisvalues(data);
}

QVector<qreal> ViewController::getaxisvaluesweather()
{
    chartData data = getweathervalues();
    return calcaxisvalues(data);
}

QVector<qreal>ViewController::calcaxisvalues(QList<QPointF> data)
{
    int length = data.length();
    qreal ymin, ymax, xmin, xmax;
    if(length == 0){
        xmin = 0;xmax = 1;ymin = 0;ymax = 1000;
    }else{

        QPointF temppoint;
        xmin = data.at(0).x();
        xmax = data.at(0).x();
        ymin = data.at(0).y();
        ymax = data.at(0).y();

        for (int iter = 1; iter < length; ++iter) {
            temppoint = data.at(iter);
            if(temppoint.x()<xmin){
                xmin = temppoint.x();
            }else if(temppoint.x()>xmax){
                xmax = temppoint.x();
            }if(temppoint.y()<ymin){
                ymin = temppoint.y();
            }else if(temppoint.y()>ymax){
                ymax = temppoint.y();
            }
        }
    }

    QVector<qreal> axismaxes = {xmin, xmax, ymin,ymax};

    return axismaxes;
}

void ViewController::saveLocal(QVector<QString> parameterstosave)
{
    std::cout<<"saving data"<<std::endl;    
    QString weathertype = parameterstosave.at(0);
    QString city = parameterstosave.at(1);
    QString energytype = parameterstosave.at(2);
    setEnergyType(energytype);
    setWeatherType({weathertype, city});
    energyDataBank_->saveDataSelection(energytodraw_);
    weatherDataBank_->saveDataSelection(weathertodraw_,currentcity_);

}

void ViewController::loadLocal(QVector<QString> parameterstoload)
{
    QString weathertype = parameterstoload.at(0);
    QString city = parameterstoload.at(1);
    QString energytype = parameterstoload.at(2);
    setEnergyType(energytype);
    setWeatherType({weathertype, city});
    energyDataBank_->readFromFile(energytodraw_);
    weatherDataBank_->readFromFile(weathertodraw_,currentcity_);
}

bool ViewController::getdeletedata()
{
    delete weatherDataBank_;
    delete energyDataBank_;
    weatherDataBank_ = new  WeatherDataBank();
    energyDataBank_ = new EnergyDataBank();
    return true;
}

bool ViewController::fetchenergy()
{
    energyDataBank_->getDataBetweenWithSplitted(energytodraw_,dates_.at(0), dates_.at(1), times_.at(0), times_.at(1));
    return true;
}

bool ViewController::fetchweather()
{
    weatherDataBank_->getDataByLocationWithSplitted(weathertodraw_, dates_.at(0), dates_.at(1), times_.at(0), times_.at(1), currentcity_);
    return true;
}

bool ViewController::loadpreference()
{
    std::vector<ApiType> types = weatherDataBank_->readPreferences();
    std::vector<ApiType> typese = energyDataBank_->readPreferences();
    if(types.size() > 0){
        weathertodraw_ = types.at(0);
    }else{
        std::cout<<"unsuccesful"<<std::endl;
        return false;
    }if(typese.size() > 0){
        energytodraw_ = typese.at(0);
    }else{
        std::cout<<"unsuccesful"<<std::endl;
        return false;
    }
    energyDataBank_->getDataBetweenWithSplitted(energytodraw_,dates_.at(0), dates_.at(1), times_.at(0), times_.at(1));
    weatherDataBank_->getDataByLocationWithSplitted(weathertodraw_, dates_.at(0), dates_.at(1), times_.at(0), times_.at(1), "turku");

    return true;
}

void ViewController::savepreference(QVector<QString> preferences)
{
    setWeatherType({preferences.at(0),"turku"});
    setEnergyType(preferences.at(1));
    energyDataBank_->savePreferences({energytodraw_});
    weatherDataBank_->savePreferences({weathertodraw_});
}

void ViewController::setEnergyType(QString value)
{
    if(value == "Total Production"){
        energytodraw_ = ApiType::PRODUCTION_TOTAL_FIN;
    }else if(value == "Total Consumption"){
        energytodraw_ = ApiType::CONSUMPTION_FIN;
    }else if(value == "Production Prediction"){
        energytodraw_ = ApiType::PRODUCTION_PREDICTION_24H_FIN;
    }else if(value == "Consumption Prediction"){
        energytodraw_ = ApiType::CONSUMPTION_FORECAST_24H_FIN;
    }else if(value == "Wind Production"){
        energytodraw_ = ApiType::WIND_PRODUCTION;
    }else if (value == "Nuclear Production"){
        energytodraw_ = ApiType::NUCLEAR_PRODUCTION;
    }else if(value == "Hydro Production"){
        energytodraw_ = ApiType::HYDRO_PRODUCTION;
    }else{
        std::cout <<"Unable to read combobox"<<std::endl;
    }   
}

void ViewController::setWeatherType(QVector<QString> weatherandcity)
{

    QString type = weatherandcity.at(0);
    QString city = weatherandcity.at(1);
    if(type == "Temperature"){
        weathertodraw_ = ApiType::TEMPERATURE ;
    }
    else if(type == "Wind Speed"){
        weathertodraw_ = ApiType::WINDSPEED;
    }
    else if(type == "Cloudiness"){
        weathertodraw_ = ApiType::CLOUDINESS;
    }
    else if(type == "Wind Prediction"){
        weathertodraw_ = ApiType::WIND_PREDICTION;
    }
    else if(type == "Temperature Prediction"){
        weathertodraw_ = ApiType::TEMPERATURE_PREDICTION;
    }else{
        std::cout <<"Unable to read combobox"<<std::endl;
    }
    currentcity_ = city;

}

void ViewController::setDate(QVector<QDate> dates, QVector<QTime> times)
{
    dates_ = dates;
    times_ = times;
}
QList<QPointF> ViewController::getweathervalues()
{
    QList<QPointF> series = weatherDataBank_->getDataForChart(weathertodraw_, currentcity_);
    return series;
}
