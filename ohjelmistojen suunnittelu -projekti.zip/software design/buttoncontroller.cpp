#include "buttoncontroller.hh"
#include <iostream>
ButtonController::ButtonController(QObject *parent) : QObject(parent)
{

}

void ButtonController::setWeatherAndCity(QVector<QString> vectorstring)
{
    weatherAndCity_ = vectorstring;
   std::cout << weatherAndCity_.at(0).toStdString();
    emit WeatherorCityChanged(weatherAndCity_);
}

QVector<int> ButtonController::getDate()
{
    return date_;
}

void ButtonController::setDate(QVector<int> date)
{
    date_ = date;
    QDate fromdate = QDate(date.at(3),date.at(2),date.at(1));
    QDate todate = QDate(date.at(7),date.at(6),date.at(5));
    QTime fromtime = QTime(date.at(0),0,0);
    QTime totime = QTime(date.at(4),0,0);
    emit dateSignal({fromdate,todate}, {fromtime,totime});
}
void ButtonController::setEnergyType(QString energytype)
{
    energyType_ = energytype;
    std::cout << energyType_.toStdString();
    emit energyTypeChanged(energyType_);
}
void ButtonController::setWeatherAndCityAndEnergyForSave(QVector<QString> weatherCityEnergy)
{
    weatherAndCityAndEnergySave_ = weatherCityEnergy;
    emit savesignal(weatherAndCityAndEnergySave_);
}

void ButtonController::setWeatherAndCityAndEnergyForLoad(QVector<QString> weatherCityEnergy)
{
    weatherAndCityAndEnergyLoad_ = weatherCityEnergy;
    emit loadsignal(weatherAndCityAndEnergyLoad_);
}

void ButtonController::setBothTypes(QVector<QString> bothtypes)
{
    emit preferencetosavesignal(bothtypes);
}
QString ButtonController::getEnergyType()
{
    return energyType_;

}
QVector<QString> ButtonController::getWeatherAndCity()
{
    return weatherAndCity_;

}

