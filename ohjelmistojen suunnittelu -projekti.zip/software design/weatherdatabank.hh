#ifndef WEATHERDATABANK_HH
#define WEATHERDATABANK_HH

#include "databankinterface.hh"
#include "networkhandler.hh"
#include "qstringdataxml.hh"

#include <QtXml>
#include <QXmlStreamReader>

#include <QTime>
#include <QDate>
#include <map>
#include <vector>
#include <string>
#include <iostream>


class WeatherDataBank: public DataBankInterface
{
public:
    WeatherDataBank();
    ~WeatherDataBank();

    using timeBasedData = std::map<QDate, std::map<QTime, double>>;
    using timeBasedData_forEachApi = std::map<QString, std::map<ApiType, std::map<QDate, std::map<QTime, double>>>>;


    /**
     * @brief getData
     * overridden from DataBankInterface
     * @param type
     * @param startTime
     * @param endTime
     */
    void getData(ApiType type, QString startTime, QString endTime) override;

    /**
     * @brief getDataBetween
     * @param type
     * @param StartDate
     * @param EndDate
     * @param StartTime
     * @param EndTime
     */
    void getDataBetween(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime) override;

    void getDataByLocationWithSplitted(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime, QString location);

    /**
     * @brief getDataByLocation
     * @param type
     * @param StartDate
     * @param EndDate
     * @param StartTime
     * @param EndTime
     * @param location
     */
    void getDataByLocation(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime, QString location);

    void saveCurrentSelection() override;
    void saveHistoryData() override;

    virtual void printDatabase() override;

    chartData getDataForChart(ApiType type, QString location = "") override;

    void convertData(QString content, ApiType type, QString location);
    void saveToDatabase(QDate date, QTime time, double value, ApiType type, QString currentLocation);
    void setTimestep(int tstep);
    bool saveDataSelection(ApiType type, QString location);
    bool readFromFile(ApiType type, QString location);
    void savePreferences(std::vector<ApiType> types);
    std::vector<ApiType> readPreferences();
    QString openAndReadFile(QString fileLocation);
private slots:
    void getRequestReady();
private:
    ApiType currentType_;
    QString currentLocation_;

    bool stillSearching = false;
    json j;
    QDate current_StartDate;
    QDate current_EndDate;
    QTime current_StartTime;
    QTime current_EndTime;

    timeBasedData data_;
    timeBasedData_forEachApi dataForEachApi_;
    // for handling network requests
    NetworkHandler* networkHandler_;
    QStringDataXml* xmlStringProcessor_ = new QStringDataXml();
    QString fmiUrl_ = "https://opendata.fmi.fi/wfs?request=getFeature&version=2.0.0";
    //data timestep (minutes)
    QString timestep_ = "60";
    std::map<ApiType, QString> ApiTypeUrlParams = {
        {ApiType::WINDSPEED, "ws_10min"},
        {ApiType::TEMPERATURE, "t2m"},
        {ApiType::CLOUDINESS, "n_man"},
        {ApiType::WIND_PREDICTION, "WindSpeedMS"},
        {ApiType::TEMPERATURE_PREDICTION, "Temperature"}
    };
//  Observed values use storedquery_id
    QString observation_storedquery_id = "&storedquery_id=fmi::observations::weather::timevaluepair";
//  &place=Tampere
//  &parameters=TA_PT1H_AVG
    // Temperature TA_PT1H_AVG, TA_PT1H_MAX, TA_PT1H_MIN
    // Observed wind WS_PT1H_AVG, WS_PT1H_MAX, WS_PT1H_MIN
    // Observed cloudiness n_man
//  Forecast values use storedquery_id
    QString forecast_storedquery_id = "&storedquery_id=fmi::forecast::harmonie::surface::point::timevaluepair";
//  &storedquery_id=fmi::forecast::harmonie::surface::point::simple
    // Predicted wind WindSpeedMS
    // Predicted temperature Temperature

    // EI PAKOLLISIA:
    // ----
    // Relative humidity RH_PT1H_AVG
    // Wind direction WD_PT1H_AVG
    // Precipitation amount: PRA_PT1H_ACC
    // Maximum precipitation intensity: PRI_PT1H_MAX
    // Air pressure PA_PT1H_AVG
    // Present weather (auto) WAWA_PT1H_RANK
    // ----
    // current working directory
    QDir d = QDir(".");
    // s.json file path, relative to current working directory
    QString historyDataFilepath_ = d.absolutePath() + "/../nyman_kanerva_hautala_kelavuori/historydata.json";
    QString selectionDataFilepath_ = d.absolutePath() + "/../nyman_kanerva_hautala_kelavuori/userSelections.json";
    //starttime ja endtime muotoa 2021-01-19T09:00:00Z
};

#endif // WEATHERDATABANK_HH
