#ifndef QSTRINGDATAXML_HH
#define QSTRINGDATAXML_HH

#include "qstringdatainterface.hh"
#include <QTime>
#include <QDate>

class QStringDataXml : public QStringDataInterface
{
public:
    QStringDataXml();
    ~QStringDataXml() = default;

    QDate convertToDate(std::string input) override;
    QTime convertToTime(std::string input) override;
    QString buildTimeQString(QDate date, QTime time) override;
    std::string convertToString(int number) override;
    std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false) override;
};

#endif // QSTRINGDATAXML_HH
