#ifndef SUUREDATA_H
#define SUUREDATA_H

#include <map>
#include <string>
#include <vector>

#include <algorithm>
#include <utility>

#include <iostream>


class SuureData
{
public:
    SuureData();
    virtual ~SuureData();

    using timeBasedData = std::map<int, std::map<int, std::map<double, double>>>;

    /**
     * @brief addValueWith_Y_D_M_H_S
     * Add a new value based on time
     * @param year
     * @param month
     * @param day
     * @param hour
     * @param min
     * @param sec
     * @param value: value of the quantity
     * @param type: 1: history; 2: forecast
     */
    void addValueWith_Y_D_M_H_S(int year, int month, int day,int hour,
                                int min, double sec, double value, int type);

    timeBasedData &getType(int type);

    void printDatabase(int type);

private:
    void StoreToDatabase(int year, int day, double min, double value, timeBasedData &db);

    timeBasedData quantityHistory;
    timeBasedData quantityForecast;

};

#endif // SUUREDATA_H
