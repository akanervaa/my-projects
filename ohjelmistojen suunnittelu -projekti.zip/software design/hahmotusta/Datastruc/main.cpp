#include <iostream>

#include "suuredata.h"

int main()
{
    SuureData* Temperature = new SuureData();

    Temperature->addValueWith_Y_D_M_H_S(2021, 3, 3, 9, 13,19,-0.2, 1);
    Temperature->addValueWith_Y_D_M_H_S(1945, 12,25,23,45,0 ,-32,  1);

    Temperature->printDatabase(1);

    return 0;
}
