#include "suuredata.h"

SuureData::SuureData()
{

}

SuureData::~SuureData()
{

}

void SuureData::addValueWith_Y_D_M_H_S(int year,
                                       int month,
                                       int day,
                                       int hour,
                                       int min,
                                       double sec,
                                       double value,
                                       int type)
{
    StoreToDatabase(year,
              month*30 + day,
              hour*60 + min + sec/60,
              value,
              getType(type));
}

SuureData::timeBasedData &SuureData::getType(int type)
{
    if (type == 1) {
        return quantityHistory;
    }
    else if (type == 2) {
        return quantityForecast;
    }
    else {
        timeBasedData empty;
        return empty;
    }
}

void SuureData::printDatabase(int type)
{
    timeBasedData &db = getType(type);

    for (auto& year : db) {
        for (auto& day : year.second) {
            for (auto& min : day.second) {
                std::cout <<
                             "arvo: " <<
                             min.second <<
                             "   min: " <<
                             min.first <<
                             "   paiva: " <<
                             day.first <<
                             "   vuosi: " <<
                             year.first << std::endl;
            }
        }
    }
}

void SuureData::StoreToDatabase(int year,
                          int day,
                          double min,
                          double value,
                          timeBasedData &db)
{

    // If there is no year, day and min yet:

    if (db.find(year) == db.end()) {
        db[year][day][min];
    }

    if (db.at(year).find(day) == db.at(year).end()) {
        db.at(year)[day][min];
    }

    if (db.at(year).at(day).find(day) == db.at(year).at(day).end()) {
        db.at(year).at(day)[min];
    }

    // Store to database
    db.at(year).at(day).at(min) = value;
}
