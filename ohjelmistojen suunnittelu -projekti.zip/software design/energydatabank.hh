#ifndef ENERGYDATABANK_HH
#define ENERGYDATABANK_HH

#include "databankinterface.hh"
#include "networkhandler.hh"
#include "qstringdatajson.hh"
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <map>
#include <iostream>
#include <QDir>
#include <QPointF>


using json = nlohmann::json;
using chartData = QList<QPointF>;
using timeBasedData = std::map<QDate, std::map<QTime, double>>;
using timeBasedData_forEachApi = std::map<ApiType, std::map<QDate, std::map<QTime, double>>>;

class EnergyDataBank: public DataBankInterface
{

public:
    EnergyDataBank();
    ~EnergyDataBank() override;
    /**
     * @brief Get data points of type ApiType from Fingrid API, between startTime and endTime.
     * Note that Fingrid uses UTC time (2 hours behind Finnish time)
     * @param type: ApiType for what kind of data to get
     * @param startTime: MUST be in form yyyy-MM-ddThh:mm:ss+0000
     * @param endTime: MUST be in form yyyy-MM-ddThh:mm:ss+0000
     */
    void getData(ApiType type, QString startTime, QString endTime) override;
    void saveCurrentSelection() override;
    // ei toimi vielä
    bool saveDataSelection(ApiType type);
    // ei toimi vielä
    bool readFromFile(ApiType type);
    void getDataBetweenWithSplitted(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime);
    std::vector<ApiType> readPreferences();
    QString openAndReadFile(QString fileLocation);
    void savePreferences(std::vector<ApiType> types);
    void saveHistoryData() override;



    std::map<ApiType, std::map<QDate, float>> returnEnergyValues();

    void printDatabase() override;
    void getDataBetween(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime) override;
    chartData getDataForChart(ApiType type, QString location = "") override;


    // 1. pitää pystyä tallentamaan tämän hetken valinnat
    // 2. pitää pystyä tallentamaan dataa reaaliajassa historia-dataksi
    // 3. prosenttiosuuksia eri sähköntuotannoista (hydro, wind, nuclear)

private slots:
    void getRequestReady();

private:
    ApiType currentType_;
    timeBasedData_forEachApi dataForEachApi_;

    bool stillSearching = false;

    QDate current_StartDate;
    QDate current_EndDate;
    QTime current_StartTime;
    QTime current_EndTime;



    // for handling network requests
    NetworkHandler* networkHandler_;
    QStringDataJson stringProcessor_;
    // energy values: stored in the format
    // <ApiType : <yyyy-MM-ddThh:mm:ss+0000 : float>>
    std::map<ApiType, std::map<QString, float>> energyValues_;
    const QString fingridUrl_ = "https://api.fingrid.fi/v1/variable/variableId/events/json";
    // Map for coverting Energy ApiType to variableId in fingrid URL
    std::map<ApiType, int> ApiTypeVariableIds = {
        {ApiType::CONSUMPTION_FIN, 124},
        {ApiType::CONSUMPTION_FORECAST_24H_FIN, 165},
        {ApiType::PRODUCTION_TOTAL_FIN, 74},
        {ApiType::PRODUCTION_PREDICTION_24H_FIN, 242},
        {ApiType::WIND_PRODUCTION, 181},
        {ApiType::NUCLEAR_PRODUCTION, 188},
        {ApiType::HYDRO_PRODUCTION, 191}
    };

    timeBasedData data_;
    QString saveDataFileName_ = "s.json";
    json j;
    // current working directory
    QDir d = QDir(".");
    // s.json file path, relative to current working directory
    QString historyDataFilepath_ = d.absolutePath() + "/../nyman_kanerva_hautala_kelavuori/historydata.json";
    QString selectionDataFilepath_ = d.absolutePath() + "/../nyman_kanerva_hautala_kelavuori/userSelections.json";
    void ConvertData(QString content, ApiType type);
    void saveToDatabase(QDate date, QTime time, double value, ApiType type);

};

#endif // ENERGYDATABANK_HH
