#include "qstringdatajson.hh"


QStringDataJson::QStringDataJson()
{

}

QStringDataJson::~QStringDataJson()
{

}

std::string QStringDataJson::convertToString(int number)
{
    if (number<10) {
        return "0" +std::to_string(number);
    }
    else {
        return std::to_string(number);
    }
}

std::vector<std::string> QStringDataJson::split(const std::string &s, const char delimiter, bool ignore_empty)
{
    std::vector<std::string> result;
    std::string tmp = s;

    while(tmp.find(delimiter) != std::string::npos)
    {
        std::string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}

QString QStringDataJson::buildTimeQString(QDate date, QTime time)
{
    std::string timeString = std::to_string(date.year())
            + "-"
            + convertToString(date.month())
            + "-"
            + convertToString(date.day())
            + "T"
            + convertToString(time.hour())
            + ":"
            + convertToString(time.minute())
            + ":"
            + convertToString(time.second())
            + "+0000";

    //std::cout << timeString << std::endl;

    return QString::fromStdString(timeString);
}

QDate QStringDataJson::convertToDate(std::string input)
{
    auto parts = split(input, '-');

    return QDate(std::stoi(parts.at(0)),
                 std::stoi(parts.at(1)),
                 std::stoi(parts.at(2)));
}

QTime QStringDataJson::convertToTime(std::string input)
{
    auto parts = split(input, '+');
    auto parts_sub = split(parts.at(0), ':');

    return QTime(std::stoi(parts_sub.at(0)),
                 std::stoi(parts_sub.at(1)),
                 std::stoi(parts_sub.at(2)));
}
