#ifndef DATABANKINTERFACE_HH
#define DATABANKINTERFACE_HH
#include <QObject>
#include "json.hpp"

// TYPES OF DATA TO BE RETRIEVED FROM THE INTERNET

// --- Fingrid API ---
// Electricity consumption in Finland
// Electricity consumption forecast for the next 24 hours.
// A tentative production prediction for the next 24 hours as hourly energy
// Electricity production in Finland
// Wind power production forecast
// Nuclear power production
// Hydro power production
enum ApiType{
    CONSUMPTION_FIN,
    CONSUMPTION_FORECAST_24H_FIN,
    PRODUCTION_PREDICTION_24H_FIN,
    PRODUCTION_TOTAL_FIN,
    WIND_PRODUCTION,
    NUCLEAR_PRODUCTION,
    HYDRO_PRODUCTION,
// --- Ilmatieteen laitos ---
// Temperature
// Observed wind
// Observed cloudiness
// Predicted wind
// Predicted temperature
    TEMPERATURE,
    WINDSPEED,
    CLOUDINESS,
    WIND_PREDICTION,
    TEMPERATURE_PREDICTION
};


using json = nlohmann::json;
using chartData = QList<QPointF>;

class DataBankInterface: public QObject
{
public:
    DataBankInterface() = default;
    virtual ~DataBankInterface() = default;

    /**
     * @brief Get data points of type ApiType between startTime and endTime
     * @param type: ApiType for what kind of data to get
     * @param startTime, endTime: string with Date and Time information
     * for example in the form: yyyy-MM-ddThh:mm:ss+0000
     */
    virtual void getData(ApiType type, QString startTime, QString endTime) = 0;

    /**
     * @brief getDataBetween same as function getData, but time is represented
     * as QDate and QTime objects
     */
    virtual void getDataBetween(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime) = 0;

    /**
     * @brief saveCurrentSelection of data
     * IDEA TULEVAISUUTTA VARTEN
     */
    virtual void saveCurrentSelection() = 0;

    /**
     * @brief saveHistoryData - initiate history data collection
     * IDEA TULEVAISUUTTA VARTEN
     */
    virtual void saveHistoryData() = 0;

    virtual void printDatabase() = 0;

    /**
     * @brief getDataForChart
     * @return
     */
    virtual chartData getDataForChart(ApiType type, QString location = "") = 0;
};

#endif // DATABANKINTERFACE_HH
