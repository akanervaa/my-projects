#ifndef BUTTONCONTROLLER_HH
#define BUTTONCONTROLLER_HH
//QVector<QString> values
#include <QObject>
#include <QtCharts>
class ButtonController : public QObject
{

    Q_OBJECT
    Q_PROPERTY(QVector<QString> getweatherAndCity READ getWeatherAndCity WRITE setWeatherAndCity)
    Q_PROPERTY(QString getEnergyType READ getEnergyType WRITE setEnergyType)
    Q_PROPERTY(QVector<int> getDate READ getDate WRITE setDate)
    Q_PROPERTY(QVector<QString> getWeatherAndCityAndEnergySave WRITE setWeatherAndCityAndEnergyForSave)
    Q_PROPERTY(QVector<QString> getWeatherAndCityAndEnergyLoad WRITE setWeatherAndCityAndEnergyForLoad)
    Q_PROPERTY(QVector<QString> getBothTypes WRITE setBothTypes)
public:
    explicit ButtonController(QObject *parent = nullptr);
    void setWeatherAndCity(QVector<QString> string);
    QVector<QString> getWeatherAndCity();
    QVector<int> getDate();
    void setDate(QVector<int> date);
    QString getEnergyType();
    void setEnergyType(QString energytype);
    void setWeatherAndCityAndEnergyForSave(QVector<QString> weatherCityEnergy);
    void setWeatherAndCityAndEnergyForLoad(QVector<QString> weatherCityEnergy);
    void setBothTypes(QVector<QString> bothtypes);
signals:
    void savesignal(QVector<QString> weatherCityEnergy);
    void loadsignal(QVector<QString> weatherCityEnergy);
    void preferencetosavesignal(QVector<QString> bothtypes);
    void WeatherorCityChanged(QVector<QString> weatherandcity);
    void energyTypeChanged(QString energytype_);
    void dateSignal(QVector<QDate> dates, QVector<QTime> times);
private:
    QVector<QString> weatherAndCityAndEnergySave_;
    QVector<QString> weatherAndCityAndEnergyLoad_;
    QString energyType_;
    QVector<QString> weatherAndCity_;
    QVector<int> date_;




signals:

};

#endif // BUTTONCONTROLLER_HH
