#ifndef QSTRINGDATAINTERFACE_HH
#define QSTRINGDATAINTERFACE_HH
#include <QDate>
#include <vector>

class QStringDataInterface
{
  public:
    virtual QDate convertToDate(std::string input) = 0;
    virtual QTime convertToTime(std::string input) = 0;
    virtual QString buildTimeQString(QDate date, QTime time) = 0;
    virtual std::string convertToString(int number) = 0;
    virtual std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false) = 0;
};

#endif // QSTRINGDATAINTERFACE_HH
