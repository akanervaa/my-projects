#include "networkhandler.hh"

#include <QByteArray>
#include <QDebug>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QStringList>
#include <QVariant>

NetworkHandler::NetworkHandler(QObject *parent) :
    QObject{ parent },
    network_{ new QNetworkAccessManager(this) },
    currentUrl_{ "" },
    currentStatuscode_{ 0 },
    currentContent_{ "" }
{
    // connect the "finished" signal from the network to the requestCompleted function
    connect(network_, &QNetworkAccessManager::finished, this, &NetworkHandler::requestCompleted);
}

NetworkHandler::~NetworkHandler()
{
    delete network_;
}

QUrl NetworkHandler::getCurrentUrl() const
{
    return currentUrl_;
}

int NetworkHandler::getCurrentStatuscode() const
{
    return currentStatuscode_;
}

QString NetworkHandler::getCurrentContent() const
{
    return currentContent_;
}

void NetworkHandler::requestUrl(const QString& url, const QString& header)
{
    if (url == "")
    {
        return;
    }

    QNetworkRequest request{ url };

    // the header parameter is assumed to be in format "<header_name>:<header_value>"
    if (header != "")
    {
        QStringList headerParts{ header.split(":") };
        if (headerParts.length() == 2)
        {
            QString headerName{ headerParts[0] };
            QString headerValue{ headerParts[1] };
            if (headerName != "" && headerValue != "")
            {
                // set the header and its value to the request
                request.setRawHeader(headerName.toUtf8(), headerValue.toUtf8());
            }
        }
    }

    // connect a network error signal to the requestError function
    QNetworkReply* networkReply{ network_->get(request) };
    connect(
        networkReply,
        #if (QT_VERSION >= QT_VERSION_CHECK(5, 15, 0))
            QOverload<QNetworkReply::NetworkError>::of(&QNetworkReply::errorOccurred),
        #else
            QOverload<QNetworkReply::NetworkError>::of(&QNetworkReply::error),
        #endif
        this,
        &NetworkHandler::requestError
    );

    qDebug() << "Request:" << request.url() << "headers:" << request.rawHeaderList();
}

void NetworkHandler::requestCompleted(QNetworkReply* networkReply)
{
    currentUrl_ = networkReply->url();
    emit currentUrlChanged();

    QVariant statuscodeVariant{ networkReply->attribute(QNetworkRequest::HttpStatusCodeAttribute) };
    currentStatuscode_ = statuscodeVariant.toInt();
    emit currentStatuscodeChanged();

    QByteArray responseContent{ networkReply->readAll() };
    currentContent_ = QString(responseContent);
    // normally the parsing of the response would be done here, in this case just show the raw content
    emit currentContentChanged();

    qDebug() << "Reply to" << networkReply->url() << "with status code:" << statuscodeVariant.toInt();
}

void NetworkHandler::requestError(QNetworkReply::NetworkError errorCode)
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    qDebug() << "Received error:" << errorCode << "for url:" << reply->url();
}
