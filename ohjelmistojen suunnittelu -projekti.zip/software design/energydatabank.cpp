#include "energydatabank.hh"
#include <QDebug>
#include <QString>
#include <QTextCodec>
#include <QUrl>
#include <QFile>
#include <QCoreApplication>
#include <fstream>
#include <QDir>
#include <QDateTime>

EnergyDataBank::EnergyDataBank():
    networkHandler_(new NetworkHandler())
{
    connect(networkHandler_, &NetworkHandler::currentContentChanged,
            this, &EnergyDataBank::getRequestReady);
}

EnergyDataBank::~EnergyDataBank()
{
    delete networkHandler_;
}

void EnergyDataBank::getData(ApiType type, QString startTime, QString endTime)
{
    currentType_ = type;

    QString url = fingridUrl_;
    // add corresponding variableId to URL
    QString replacedString("variableId");
    std::map<ApiType,int>::iterator it = ApiTypeVariableIds.find(type);
    if( it != ApiTypeVariableIds.end() ) {
        url = url.replace(url.indexOf(replacedString),
                          replacedString.size(), QString::number(it->second));
    } else{
        qDebug() << "EnergyDataBank::getData(): ApiType not found in Fingrid API";
        return;
    }
    url += "?start_time=" +  QUrl::toPercentEncoding(startTime) +
            "&end_time=" + QUrl::toPercentEncoding(endTime);
    networkHandler_->requestUrl(url, "x-api-key:LCffrkCGfb66jKvSbTgeq7aEtCCGj8CP8U68H1Qd");
}

void EnergyDataBank::saveCurrentSelection()
{

}

bool EnergyDataBank::saveDataSelection(ApiType type)
{
    // current date and time in utc
    QDateTime currDt = QDateTime::currentDateTimeUtc();
    std::string currDtS = stringProcessor_.buildTimeQString(currDt.date(), currDt.time()).toStdString();
    // open file
    QFile saveFile(selectionDataFilepath_);
    if (!saveFile.exists()) {
        qWarning() << "SaveDataSelection: save file doesn't exist";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
        return false;
    }
    //read file
    QString filecontent = saveFile.readAll();
    // parse json content
    if( filecontent != "" or filecontent != "null" ){
        j = json::parse(filecontent.toStdString());
    } else {
        qWarning() << "empty json file";
        return false;
    }
    // reset values for type is json file
    int ti = type;
    std::string t = std::to_string(ti);
    json emptyj;
    j["fingrid"][t] = emptyj;
    // loop through dataForEachApi
    timeBasedData_forEachApi::iterator findit = dataForEachApi_.find(type);
    if( findit != dataForEachApi_.end() ) {
        //type
        timeBasedData apidata = dataForEachApi_.at(type);
        for( std::pair<QDate, std::map<QTime, double>> datedata : apidata ){
            // datestring for json
            std::string datestring =
                    std::to_string(datedata.first.year()) +
                    "-" +
                    stringProcessor_.convertToString(datedata.first.month()) +
                    "-" +
                    stringProcessor_.convertToString(datedata.first.day());
            for( std::pair<QTime, double> timevalpair : datedata.second ){
                //timestring for json
                std::string timestring =
                        stringProcessor_.convertToString(timevalpair.first.hour()) +
                        ":" +
                        stringProcessor_.convertToString(timevalpair.first.minute()) +
                        ":" +
                        stringProcessor_.convertToString(timevalpair.first.second()) +
                        "+0000";
                //value
                // add data to json
                j["fingrid"][t][datestring][timestring] = timevalpair.second;
            }
        }
    }
    //    std::cout << j.dump(4);
    // empty current file
    saveFile.resize(0);
    // write new json content to file
    QTextStream outStream(&saveFile);
    outStream << QString::fromStdString(j.dump(4));
    saveFile.close();
    return true;
}

bool EnergyDataBank::readFromFile(ApiType type)
{
    // open file
    QFile saveFile(selectionDataFilepath_);
    if (!saveFile.exists()) {
        qWarning() << "readFromFile: file doesn't exist: " << selectionDataFilepath_;
        return false;
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
        return false;
    }
    //read file
    QString filecontent = saveFile.readAll();
    //close file
    saveFile.close();
    // file content into nlohmann::json
    if( filecontent != "" or filecontent != "null" ){
        j = json::parse(filecontent.toStdString());
    } else{
        qWarning() << "in readFromFile: file content empty or null";
    }
    // for storing the data
//    timeBasedData filedata;
//    timeBasedData tbd;
    int ti = type;
    std::string t = std::to_string(ti);
    // parse json content into timeBasedData
    for (json::iterator fin = j.begin(); fin != j.end(); ++fin){
        if( fin.key() == "fingrid" ) {
            json apij = fin.value();
            qDebug() << QString::fromStdString(fin.key());
            for( json::iterator apitype = apij.begin(); apitype != apij.end(); ++apitype ){
                if( apitype.key() == t ){
                    qDebug() << QString::fromStdString(apitype.key());
                    json datej = apitype.value();
                    for( json::iterator date = datej.begin(); date != datej.end(); ++date ){
//                        std::map<QTime, double> tmap;
                        json timej = date.value();
                        qDebug() << QString::fromStdString(date.key());
                        for( json::iterator timevalpair = timej.begin(); timevalpair != timej.end(); ++timevalpair ){
                            qDebug() << QString::fromStdString(timevalpair.key());
//                            tmap.insert({stringProcessor_.convertToTime(timevalpair.key()), timevalpair.value()});
//                            filedata.insert({stringProcessor_.convertToDate(date.key()), tmap});
                            QDate d = stringProcessor_.convertToDate(date.key());
                            QTime t = stringProcessor_.convertToTime(timevalpair.key());
                            saveToDatabase(d, t,timevalpair.value(),type);
                        }
                    }
                }
            }
        }
    }
    qDebug() << "readFromFile database:";
    printDatabase();
    return true;
}

// timeBasedData t = readFromFile(type);
// savetodatabase t
// getdataforchart

void EnergyDataBank::getDataBetweenWithSplitted(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime)
{
    qint64 limit = 20;

    if (StartDate.daysTo(EndDate) <= limit) {
        stillSearching = false;
        getDataBetween(type, StartDate, EndDate, StartTime, EndTime);
        return;
    }
    else {
        current_StartTime.setHMS(0,0,0);
        current_EndTime = EndTime;
        current_StartDate = StartDate.addDays(limit);
        current_EndDate = EndDate;
        stillSearching = true;
        getDataBetween(type, StartDate, StartDate.addDays(limit), StartTime, QTime(0,0,0));
        return;
    }
}

void EnergyDataBank::saveHistoryData()
{

}


std::map<ApiType, std::map<QDate, float> > EnergyDataBank::returnEnergyValues()
{
    //    return energyValues_;
}


void EnergyDataBank::ConvertData(QString content, ApiType type)
{
    std::cout << "ollaan convertoimassa" << std::endl;

    json jsonContent = json::parse(content.toStdString());;

    for (auto item : jsonContent) {

        std::vector<std::string> parts = stringProcessor_.split(item["start_time"], 'T');
        auto Date = stringProcessor_.convertToDate(parts.at(0));
        auto Time = stringProcessor_.convertToTime(parts.at(1));

        double Value = item["value"];
        //double value = std::stod(what);
        //std::cout << typeid(value).name() << std::endl;

        saveToDatabase(Date, Time, Value, type);
    }

    if (stillSearching) {
        getDataBetweenWithSplitted(currentType_, current_StartDate, current_EndDate, current_StartTime, current_EndTime);
    }
    else {
        // saatiin päätökseen haku
        printDatabase();
    }

    //getDataForChart(type);

}


void EnergyDataBank::saveToDatabase(QDate date, QTime time, double value, ApiType type)
{
    /*
    std::cout << date.dayOfWeek()
              << " h: "
              << time.hour()
              << " value: "
              << value
              << std::endl;
              */

    // If there is no date and time yet:

    if (dataForEachApi_.find(type) == dataForEachApi_.end()) {
        dataForEachApi_[type];
    }

    if (dataForEachApi_.at(type).find(date) == dataForEachApi_.at(type).end()) {
        dataForEachApi_.at(type)[date][time];
    }

    if (dataForEachApi_.at(type).at(date).find(time) == dataForEachApi_.at(type).at(date).end()) {
        dataForEachApi_.at(type).at(date)[time];
    }

    // Store to database
    dataForEachApi_.at(type).at(date).at(time) = value;
}


void EnergyDataBank::printDatabase()
{
    if (dataForEachApi_.find(currentType_) != dataForEachApi_.end()) {
        for (auto d : dataForEachApi_.at(currentType_)) {
            for (auto t : d.second) {
                std::cout << d.first.day() <<
                             " " <<
                             t.second <<
                             std::endl;
            }
        }
    }
}

std::vector<ApiType> EnergyDataBank::readPreferences()
{
    QString content = openAndReadFile(selectionDataFilepath_);
    j = json::parse(content.toStdString());
    std::vector<ApiType> v;
    std::vector<std::string> sv = j["fingrid"]["preferences"];
    for (std::string s : sv){
        int i = stoi(s);
        ApiType a = static_cast<ApiType>(i);
        v.push_back(a);
        qDebug() << i;
    }
    return v;
}

void EnergyDataBank::savePreferences(std::vector<ApiType> types)
{
    // open file
    QFile saveFile(selectionDataFilepath_);
    if (!saveFile.exists()) {
        qWarning() << "savePreferences: save file doesn't exist";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
    }
    QString filecontent = saveFile.readAll();
    j = json::parse(filecontent.toStdString());
    j["fingrid"]["preferences"] = {};
    for( ApiType t : types ){
        int ti = t;
        std::string ts = std::to_string(ti);
        j["fingrid"]["preferences"].push_back(ts);
    }
    // empty current file
    // write new json content to file
    saveFile.resize(0);
    QTextStream outStream(&saveFile);
    outStream << QString::fromStdString(j.dump(4));
    saveFile.close();
}

QString EnergyDataBank::openAndReadFile(QString fileLocation)
{
    // open file
    QFile saveFile(fileLocation);
    if (!saveFile.exists()) {
        qWarning() << "openAndReadFile: file doesn't exist: " << selectionDataFilepath_;
        return "";
    }
    if (!saveFile.open(QIODevice::ReadWrite)){
        QString errMsg = saveFile.errorString();
        qWarning() << "Error opening file:"<<
                      saveFile.fileName() << "Error message:" << errMsg;
        return "";
    }
    QString content = saveFile.readAll();
    saveFile.close();
    return content;
}

void EnergyDataBank::getDataBetween(ApiType type, QDate StartDate, QDate EndDate, QTime StartTime, QTime EndTime)
{
    getData(type,
            QString(stringProcessor_.buildTimeQString(StartDate, StartTime)),
            QString(stringProcessor_.buildTimeQString(EndDate, EndTime)));
}

// lisää apitype
chartData EnergyDataBank::getDataForChart(ApiType type, QString location)
{
    chartData tempData;
    int j = 0;
    int k = 0;
    double average;
    int countofsum;
    int valuesinhour = 1;
    if(type == ApiType::WIND_PRODUCTION || type == ApiType::NUCLEAR_PRODUCTION || type == HYDRO_PRODUCTION){
        valuesinhour= 20;
    }else if(type == ApiType::CONSUMPTION_FORECAST_24H_FIN){
        valuesinhour = 12;
    }else{
        valuesinhour = 1;
    }
    if (dataForEachApi_.find(type) != dataForEachApi_.end()) {
        for (auto d : dataForEachApi_.at(type)) {

            for (auto t : d.second) {
                average += t.second;
                countofsum += 1;
                if(k % valuesinhour == 0){
                    tempData.insert(j, QPointF(j/static_cast<double>(24), average/countofsum));
                    j++;
                    average = 0;
                    countofsum = 0;
                }
                k++;
            }
        }
    }

    std::cout << "ollaan DataforChartissa" << std::endl;

    /*
    for (auto t : tempData) {
        std::cout << t.x() << " " << t.y() << std::endl;
    }
    */

    return tempData;
}

void EnergyDataBank::getRequestReady()
{
    QString content = networkHandler_->getCurrentContent();
    ConvertData(content, currentType_);
//    saveDataSelection(currentType_);
//    readFromFile(currentType_);
    std::vector<ApiType> a;
    a.push_back(ApiType::CONSUMPTION_FIN);
    a.push_back(ApiType::NUCLEAR_PRODUCTION);
    savePreferences(a);
    std::vector<ApiType> b = readPreferences();
    qDebug() << "b";
    qDebug() << b[0];
}
