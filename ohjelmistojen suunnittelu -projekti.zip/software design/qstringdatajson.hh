#ifndef QSTRINGDATAJSON_HH
#define QSTRINGDATAJSON_HH

#include "qstringdatainterface.hh"
#include <iostream>

class QStringDataJson: public QStringDataInterface
{
public:
    QStringDataJson();
    ~QStringDataJson();

    QDate convertToDate(std::string input) override;
    QTime convertToTime(std::string input) override;
    QString buildTimeQString(QDate date, QTime time) override;
    std::string convertToString(int number) override;
    std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false) override;
};



#endif // QSTRINGDATAJSON_HH
