// Datastructures.cc

#include "datastructures.hh"

#include <random>

#include <cmath>

std::minstd_rand rand_engine; // Reasonably quick pseudo-random generator

template <typename Type>
Type random_in_range(Type start, Type end)
{
    auto range = end-start;
    ++range;

    auto num = std::uniform_int_distribution<unsigned long int>(0, range-1)(rand_engine);

    return static_cast<Type>(start+num);
}

// Modify the code below to implement the functionality of the class.
// Also remove comments from the parameter names when you implement
// an operation (Commenting out parameter name prevents compiler from
// warning about unused parameters on operations you haven't yet implemented.)

Datastructures::Datastructures()
{

    Areas = {};
    Places = {};
}

Datastructures::~Datastructures()
{

    for (auto &areas:Areas){
        areas.second = nullptr;
    }
    for (auto &place:Places){
        place.second = nullptr;
    }
}

int Datastructures::place_count()
{

    return Places.size();
}

void Datastructures::clear_all()
{

    Places.clear();
    Areas.clear();
}

std::vector<PlaceID> Datastructures::all_places()
{

    std::vector<PlaceID> all_places = {};
    for (auto place:Places){
        all_places.push_back(place.first);
    }
    return all_places;
}

bool Datastructures::add_place(PlaceID id, const Name& name, PlaceType type, Coord xy)
{

    if (Places.find(id)==Places.end())
    {
        Places[id] = new Place(id,name,type,xy);
        return true;
    }
        return false;
}

std::pair<Name, PlaceType> Datastructures::get_place_name_type(PlaceID id)
{
    if (Places.find(id) != Places.end()){
        return {Places[id]->name, Places[id]->placetype};
    }
    return {NO_NAME,PlaceType::NO_TYPE};
}

Coord Datastructures::get_place_coord(PlaceID id)
{

    return Places[id]->coord;
}

bool Datastructures::add_area(AreaID id, const Name &name, std::vector<Coord> coords)
{

    if(Areas.find(id)==Areas.end())
    {
        Areas[id] = new Area(id,name,coords);
        return true;
    }
    return false;
}

Name Datastructures::get_area_name(AreaID id)
{

    if(Areas.find(id)==Areas.end())
    {
        return NO_NAME;
    }
    return Areas[id]->name;
}

std::vector<Coord> Datastructures::get_area_coords(AreaID id)
{

    if(Areas.find(id)==Areas.end())
    {
        return {NO_COORD};
    }
    return Areas[id]->coords;
}

void Datastructures::creation_finished()
{
    // Replace this comment with your implementation
    // NOTE!! It's quite ok to leave this empty, if you don't need operations
    // that are performed after all additions have been done.
}


std::vector<PlaceID> Datastructures::places_alphabetically()
{

    std::vector<std::pair<Name,PlaceID>> placevector;
    for (auto place:Places){
        placevector.push_back({place.second->name,place.second->Place_id});
    }
    std::sort(placevector.begin(),placevector.end());
    std::vector<PlaceID> returnvector;
    for (auto place:placevector){
        returnvector.push_back(place.second);
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::places_coord_order()
{

    std::vector<PlaceID> returnvector;
    std::vector<std::pair<float,Place*>> placevector;
    for (auto place:Places){
        placevector.push_back({sqrt(std::pow(place.second->coord.x,2)+std::pow(place.second->coord.y,2)),place.second});
    }
    std::sort(placevector.begin(),placevector.end(),[](auto i,auto j){
        if(i.first==j.first){
            return i.second->coord<j.second->coord;}
        else
            return i.first<j.first;});

    for (auto place:placevector){
        returnvector.push_back(place.second->Place_id);
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::find_places_name(Name const& name)
{

    std::vector<PlaceID> returnIDs = {};
    std::unordered_map<PlaceID,Place*>::iterator it = Places.begin();
    while(it != Places.end()){
          if (it->second->name==name){
              returnIDs.push_back(it->first);
          }
          it++;
}
    return returnIDs;
}

std::vector<PlaceID> Datastructures::find_places_type(PlaceType type)
{

    std::vector<PlaceID> returnIDs = {};
    std::unordered_map<PlaceID,Place*>::iterator it= Places.begin();
    while(it != Places.end()){
          if (it->second->placetype==type){
              returnIDs.push_back(it->first);
          }
          it++;
    }

    return returnIDs;
}

bool Datastructures::change_place_name(PlaceID id, const Name& newname)
{

    if(Places.find(id)!=Places.end()){
        Places[id]->name = newname;
        return true;
    }
    else {
        return false;
    }
}

bool Datastructures::change_place_coord(PlaceID id, Coord newcoord)
{

    if(Places.find(id)!=Places.end()){
        Places[id]->coord = newcoord;
        return true;
    }
    else {
        return false;
    }
}

std::vector<AreaID> Datastructures::all_areas()
{

    std::vector<AreaID> all_areas = {};
    for (auto area:Areas){
        all_areas.push_back(area.first);
    }
    return all_areas;
}

bool Datastructures::add_subarea_to_area(AreaID id, AreaID parentid)
{

    if(Areas.find(id)!=Areas.end() && Areas.find(parentid)!=Areas.end() && Areas[id]->parent==-1){
        Areas[id]->parent = parentid;
        Areas[parentid]->children.push_back(id);
        return true;
    }
    return false;
}

std::vector<AreaID> Datastructures::subarea_in_areas(AreaID id)
{
    std::vector<AreaID> returnvector = {};
    if (Areas.find(id) == Areas.end()){
        return {NO_AREA};
    }
    while (Areas[id]->parent != -1){
        returnvector.push_back(Areas[id]->parent);
        id = Areas[id]->parent;
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::places_closest_to(Coord xy, PlaceType type)
{
    float distance = 100000;
    float distance2 = 100000;
    float distance3 = 100000;
    std::vector<PlaceID> returnvector = {};
    std::vector<PlaceID> distancevector1 = {};
    std::vector<PlaceID> distancevector2 = {};
    std::vector<PlaceID> distancevector3 = {};
    int current_y1 = 0;
    int current_y2 = 0;
    int current_y3 = 0;
    std::vector<std::pair<float,Place*>> placevector;
    for (auto place:Places){
        if (type == PlaceType::NO_TYPE || place.second->placetype == type){
            if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance
                    or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y1)){
                current_y1 = place.second->coord.y;
                distance3 = distance2;
                distance2 = distance;

                distance = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));
                if (distancevector2.empty() == false)
                    distancevector3.push_back(distancevector2.back());
                if (distancevector1.empty() == false)
                    distancevector2.push_back(distancevector1.back());

                distancevector1.push_back(place.first);


            }

            else if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance2
                     or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y2)){
                current_y2 = place.second->coord.y;
                distance3 = distance2;
                distance2 = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));

                if (distancevector2.empty() == false)
                distancevector3.push_back(distancevector2.back());
                distancevector2.push_back(place.first);

            }
            else if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance3
                     or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y3)){
                current_y3 = place.second->coord.y;
                distance3 = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));
                distancevector3.push_back(place.first);
            }

        }
    }
    if (distancevector1.size()>0){
        returnvector.push_back(distancevector1.back());
        }
    if (distancevector2.size()>0 && distancevector1.back() != distancevector2.back()){
        returnvector.push_back(distancevector2.back());
        }
    if (distancevector3.size()>0 && distancevector2.back() != distancevector3.back()){
        returnvector.push_back(distancevector3.back());
    }

    return returnvector;
}

bool Datastructures::remove_place(PlaceID id)
{

    if(Places.find(id) == Places.end()){
        return false;
    }
    Places.erase(id);
    return true;

}

std::vector<AreaID> Datastructures::all_subareas_in_area(AreaID id)
{

    std::vector<AreaID> returnvector = {};
    if (Areas.find(id)==Areas.end()){
        return {NO_AREA};
    }
    return recursionFunction(id, returnvector);
}

AreaID Datastructures::common_area_of_subareas(AreaID id1, AreaID id2)
{

    if (Areas.find(id1) == Areas.end() || Areas.find(id2) == Areas.end()){
        return NO_AREA;
    }
    AreaID temp_id1 = id1;
    AreaID temp_id2 = id2;
    int depth_id1 = 0;
    int depth_id2 = 0;
    while (Areas[id1]->parent != -1){
        depth_id1++;
        id1 = Areas[id1]->parent;
    }
    while (Areas[id2]->parent != -1){
        depth_id2++;
        id2 = Areas[id2]->parent;
    }
    int depth_difference = depth_id2 - depth_id1;
    if (depth_difference > 0){

        for(auto j=0;j<depth_difference;++j){
                temp_id2= Areas[temp_id2]->parent;
        }
    }
    else {

        for(auto j=0;j<-1*depth_difference;++j){
                temp_id1= Areas[temp_id1]->parent;
        }
    }
    while (Areas[temp_id1]->parent != -1){

        if(Areas[temp_id1]->parent == Areas[temp_id2]->parent){
            return Areas[temp_id1]->parent;
        }
        temp_id1 = Areas[temp_id1]->parent;
        temp_id2 = Areas[temp_id2]->parent;


    }
    return NO_AREA;
}

std::vector<AreaID> Datastructures::recursionFunction(PlaceID id, std::vector<AreaID> &returnvector){
    if (Areas[id]->children.size() == 0){
        return returnvector;
    }
    for (auto child:Areas[id]->children){
        returnvector.push_back(child);
        recursionFunction(child, returnvector);
    }
    return returnvector;


}

std::vector<WayID> Datastructures::all_ways()
{
    // Replace this comment with your implementation
    std::vector<WayID> allWays = {};
    for(auto i:waypoints){
        allWays.push_back(i.first);
    }
    return allWays;
}

bool Datastructures::add_way(WayID id, std::vector<Coord> coords)
{   
    if(waypoints.find(id) == waypoints.end()){
        waypoints[id] = coords;
    }
    else {
        return false;
    }
    Distance distance = calculateDistance(coords);

    if (allIntersections.find(coords.front())==allIntersections.end()){
        Intersection* inter = new Intersection;
        inter->location = coords.front();
        allIntersections[coords.front()] = inter;
    }
    if (allIntersections.find(coords.back())==allIntersections.end()){
        Intersection* inter = new Intersection;
        inter->location = coords.back();
        allIntersections[coords.back()] = inter;
    }
    allIntersections.at(coords.front())->connections.insert({coords.back(),{id,distance}});
    allIntersections.at(coords.back())->connections.insert({coords.front(),{id,distance}});
    return true;
}

std::vector<std::pair<WayID, Coord>> Datastructures::ways_from(Coord xy)
{
    std::vector<std::pair<WayID, Coord>> wayVector = {};
    if(allIntersections.find(xy)!= allIntersections.end()){
        for(auto i:allIntersections.at(xy)->connections){
            wayVector.push_back({i.second.first,i.first});
        }
    }
    return wayVector;
}

std::vector<Coord> Datastructures::get_way_coords(WayID id)
{
    // Replace this comment with your implementation
    if(waypoints.find(id) != waypoints.end()){
        return waypoints.at(id);
    }
    return {NO_COORD};
}

void Datastructures::clear_ways()
{
    // Replace this comment with your implementation
    waypoints.clear();
    allIntersections.clear();
}

std::vector<std::tuple<Coord, WayID, Distance>> Datastructures::route_any(Coord fromxy, Coord toxy)
{
    if (allIntersections.find(fromxy) == allIntersections.end() or allIntersections.find(toxy) == allIntersections.end())
        {
            return {{NO_COORD, NO_WAY, NO_DISTANCE}};
        }
    std::deque<Coord> unvisitedCoords = {};
    std::vector<std::tuple<Coord, WayID, Distance>> route_vector = {};
    std::unordered_map<Coord, Coord, CoordHash> toFrom = {};
    unvisitedCoords.push_back(fromxy);
    if (allIntersections.at(fromxy)->connections.find(toxy) != (allIntersections.at(fromxy)->connections.end())){
        route_vector.push_back({fromxy, allIntersections.at(fromxy)->connections.at(toxy).first, 0});
        route_vector.push_back({toxy, NO_WAY, allIntersections.at(fromxy)->connections.at(toxy).second});
        return route_vector;
    }
    while (unvisitedCoords.size() != 0) {
        if(unvisitedCoords.front() == toxy){
            break;
        }
        for(auto i : unvisitedCoords){
            for( auto k : allIntersections.at(i)->connections){
                if(allIntersections.at(k.first)->visitStatus == false){
                    unvisitedCoords.push_back(k.first);
                    allIntersections.at(k.first)->visitStatus = true;
                    toFrom.insert({k.first, i});
                }
            }
        }
        unvisitedCoords.pop_front();
    }
    for (auto i: toFrom){
        allIntersections.at(i.second)->visitStatus = false;
        allIntersections.at(i.first)->visitStatus = false;
    }
    bool routeComplete = false;
    Coord currentNode = toxy;
    if (toFrom.find(toxy)==toFrom.end()){
        return route_vector;
    }

    while (!routeComplete) {
        route_vector.push_back({currentNode,
                   allIntersections.at(currentNode)->connections.at(toFrom.at(currentNode)).first, 0});
        if( currentNode == fromxy){
            routeComplete = true;
        }
        currentNode = toFrom.at(currentNode);
    }

    std::reverse(route_vector.begin(), route_vector.end());
    bool first = true;

    for ( unsigned int i = 0 ; i < route_vector.size() ; i++){
        if(first != true){
            route_vector.at(i) = {std::get<Coord>(route_vector.at(i)), std::get<WayID>(route_vector.at(i)),
                    std::get<Distance>(route_vector.at(i-1)) + calculateDistance(waypoints.at(std::get<WayID>(route_vector.at(i))))};
        }
        if(first == true){
            route_vector.at(i) = {std::get<Coord>(route_vector.at(i)), std::get<WayID>(route_vector.at(i)), 0};
            first = false;
        }
    }


    return route_vector;
}

bool Datastructures::remove_way(WayID id)
{
    // Replace this comment with your implementation
    return false;
}

std::vector<std::tuple<Coord, WayID, Distance> > Datastructures::route_least_crossroads(Coord fromxy, Coord toxy)
{
    // Replace this comment with your implementation
    return {{NO_COORD, NO_WAY, NO_DISTANCE}};
}

std::vector<std::tuple<Coord, WayID> > Datastructures::route_with_cycle(Coord fromxy)
{
    // Replace this comment with your implementation
    return {{NO_COORD, NO_WAY}};
}

std::vector<std::tuple<Coord, WayID, Distance> > Datastructures::route_shortest_distance(Coord fromxy, Coord toxy)
{
    // Replace this comment with your implementation
    return {{NO_COORD, NO_WAY, NO_DISTANCE}};
}

Distance Datastructures::trim_ways()
{
    // Replace this comment with your implementation
    return NO_DISTANCE;
}
Distance Datastructures::calculateDistance(std::vector<Coord> coords)
{
    int distance = 0;
    for (unsigned int i = 0 ; i < coords.size() - 1 ; i++) {
        distance = distance + floor(sqrt(pow(coords.at(i).x - coords.at(i + 1).x,2) + std::pow(coords.at(i).y - coords.at(i + 1).y,2)));
    }
    return distance;
}
