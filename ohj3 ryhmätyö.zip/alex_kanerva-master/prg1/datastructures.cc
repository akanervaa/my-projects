// Datastructures.cc

#include "datastructures.hh"

#include <random>

#include <cmath>

std::minstd_rand rand_engine; // Reasonably quick pseudo-random generator

template <typename Type>
Type random_in_range(Type start, Type end)
{
    auto range = end-start;
    ++range;

    auto num = std::uniform_int_distribution<unsigned long int>(0, range-1)(rand_engine);

    return static_cast<Type>(start+num);
}

// Modify the code below to implement the functionality of the class.
// Also remove comments from the parameter names when you implement
// an operation (Commenting out parameter name prevents compiler from
// warning about unused parameters on operations you haven't yet implemented.)

Datastructures::Datastructures()
{

    Areas = {};
    Places = {};
}

Datastructures::~Datastructures()
{

    for (auto &areas:Areas){
        areas.second = nullptr;
    }
    for (auto &place:Places){
        place.second = nullptr;
    }
}

int Datastructures::place_count()
{

    return Places.size();
}

void Datastructures::clear_all()
{

    Places.clear();
    Areas.clear();
}

std::vector<PlaceID> Datastructures::all_places()
{

    std::vector<PlaceID> all_places = {};
    for (auto place:Places){
        all_places.push_back(place.first);
    }
    return all_places;
}

bool Datastructures::add_place(PlaceID id, const Name& name, PlaceType type, Coord xy)
{

    if (Places.find(id)==Places.end())
    {
        Places[id] = new Place(id,name,type,xy);
        return true;
    }
        return false;
}

std::pair<Name, PlaceType> Datastructures::get_place_name_type(PlaceID id)
{
    if (Places.find(id) != Places.end()){
        return {Places[id]->name, Places[id]->placetype};
    }
    return {NO_NAME,PlaceType::NO_TYPE};
}

Coord Datastructures::get_place_coord(PlaceID id)
{

    return Places[id]->coord;
}

bool Datastructures::add_area(AreaID id, const Name &name, std::vector<Coord> coords)
{

    if(Areas.find(id)==Areas.end())
    {
        Areas[id] = new Area(id,name,coords);
        return true;
    }
    return false;
}

Name Datastructures::get_area_name(AreaID id)
{

    if(Areas.find(id)==Areas.end())
    {
        return NO_NAME;
    }
    return Areas[id]->name;
}

std::vector<Coord> Datastructures::get_area_coords(AreaID id)
{

    if(Areas.find(id)==Areas.end())
    {
        return {NO_COORD};
    }
    return Areas[id]->coords;
}

void Datastructures::creation_finished()
{
    // Replace this comment with your implementation
    // NOTE!! It's quite ok to leave this empty, if you don't need operations
    // that are performed after all additions have been done.
}


std::vector<PlaceID> Datastructures::places_alphabetically()
{

    std::vector<std::pair<Name,PlaceID>> placevector;
    for (auto place:Places){
        placevector.push_back({place.second->name,place.second->Place_id});
    }
    std::sort(placevector.begin(),placevector.end());
    std::vector<PlaceID> returnvector;
    for (auto place:placevector){
        returnvector.push_back(place.second);
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::places_coord_order()
{

    std::vector<PlaceID> returnvector;
    std::vector<std::pair<float,Place*>> placevector;
    for (auto place:Places){
        placevector.push_back({sqrt(std::pow(place.second->coord.x,2)+std::pow(place.second->coord.y,2)),place.second});
    }
    std::sort(placevector.begin(),placevector.end(),[](auto i,auto j){
        if(i.first==j.first){
            return i.second->coord<j.second->coord;}
        else
            return i.first<j.first;});

    for (auto place:placevector){
        returnvector.push_back(place.second->Place_id);
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::find_places_name(Name const& name)
{

    std::vector<PlaceID> returnIDs = {};
    std::unordered_map<PlaceID,Place*>::iterator it = Places.begin();
    while(it != Places.end()){
          if (it->second->name==name){
              returnIDs.push_back(it->first);
          }
          it++;
}
    return returnIDs;
}

std::vector<PlaceID> Datastructures::find_places_type(PlaceType type)
{

    std::vector<PlaceID> returnIDs = {};
    std::unordered_map<PlaceID,Place*>::iterator it= Places.begin();
    while(it != Places.end()){
          if (it->second->placetype==type){
              returnIDs.push_back(it->first);
          }
          it++;
    }

    return returnIDs;
}

bool Datastructures::change_place_name(PlaceID id, const Name& newname)
{

    if(Places.find(id)!=Places.end()){
        Places[id]->name = newname;
        return true;
    }
    else {
        return false;
    }
}

bool Datastructures::change_place_coord(PlaceID id, Coord newcoord)
{

    if(Places.find(id)!=Places.end()){
        Places[id]->coord = newcoord;
        return true;
    }
    else {
        return false;
    }
}

std::vector<AreaID> Datastructures::all_areas()
{

    std::vector<AreaID> all_areas = {};
    for (auto area:Areas){
        all_areas.push_back(area.first);
    }
    return all_areas;
}

bool Datastructures::add_subarea_to_area(AreaID id, AreaID parentid)
{

    if(Areas.find(id)!=Areas.end() && Areas.find(parentid)!=Areas.end() && Areas[id]->parent==-1){
        Areas[id]->parent = parentid;
        Areas[parentid]->children.push_back(id);
        return true;
    }
    return false;
}

std::vector<AreaID> Datastructures::subarea_in_areas(AreaID id)
{
    std::vector<AreaID> returnvector = {};
    if (Areas.find(id) == Areas.end()){
        return {NO_AREA};
    }
    while (Areas[id]->parent != -1){
        returnvector.push_back(Areas[id]->parent);
        id = Areas[id]->parent;
    }
    return returnvector;
}

std::vector<PlaceID> Datastructures::places_closest_to(Coord xy, PlaceType type)
{
    float distance = 100000;
    float distance2 = 100000;
    float distance3 = 100000;
    std::vector<PlaceID> returnvector = {};
    std::vector<PlaceID> distancevector1 = {};
    std::vector<PlaceID> distancevector2 = {};
    std::vector<PlaceID> distancevector3 = {};
    int current_y1 = 0;
    int current_y2 = 0;
    int current_y3 = 0;
    std::vector<std::pair<float,Place*>> placevector;
    for (auto place:Places){
        if (type == PlaceType::NO_TYPE || place.second->placetype == type){
            if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance
                    or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y1)){
                current_y1 = place.second->coord.y;
                distance3 = distance2;
                distance2 = distance;

                distance = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));
                if (distancevector2.empty() == false)
                    distancevector3.push_back(distancevector2.back());
                if (distancevector1.empty() == false)
                    distancevector2.push_back(distancevector1.back());

                distancevector1.push_back(place.first);


            }

            else if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance2
                     or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y2)){
                current_y2 = place.second->coord.y;
                distance3 = distance2;
                distance2 = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));

                if (distancevector2.empty() == false)
                distancevector3.push_back(distancevector2.back());
                distancevector2.push_back(place.first);

            }
            else if (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))< distance3
                     or (sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2))== distance and place.second->coord.y<current_y3)){
                current_y3 = place.second->coord.y;
                distance3 = sqrt(std::pow(place.second->coord.x-xy.x,2)+std::pow(place.second->coord.y-xy.y,2));
                distancevector3.push_back(place.first);
            }

        }
    }
    if (distancevector1.size()>0){
        returnvector.push_back(distancevector1.back());
        }
    if (distancevector2.size()>0 && distancevector1.back() != distancevector2.back()){
        returnvector.push_back(distancevector2.back());
        }
    if (distancevector3.size()>0 && distancevector2.back() != distancevector3.back()){
        returnvector.push_back(distancevector3.back());
    }

    return returnvector;
}

bool Datastructures::remove_place(PlaceID id)
{

    if(Places.find(id) == Places.end()){
        return false;
    }
    Places.erase(id);
    return true;

}

std::vector<AreaID> Datastructures::all_subareas_in_area(AreaID id)
{

    std::vector<AreaID> returnvector = {};
    if (Areas.find(id)==Areas.end()){
        return {NO_AREA};
    }
    return recursionFunction(id, returnvector);
}

AreaID Datastructures::common_area_of_subareas(AreaID id1, AreaID id2)
{

    if (Areas.find(id1) == Areas.end() || Areas.find(id2) == Areas.end()){
        return NO_AREA;
    }
    AreaID temp_id1 = id1;
    AreaID temp_id2 = id2;
    int depth_id1 = 0;
    int depth_id2 = 0;
    while (Areas[id1]->parent != -1){
        depth_id1++;
        id1 = Areas[id1]->parent;
    }
    while (Areas[id2]->parent != -1){
        depth_id2++;
        id2 = Areas[id2]->parent;
    }
    int depth_difference = depth_id2 - depth_id1;
    if (depth_difference > 0){

        for(auto j=0;j<depth_difference;++j){
                temp_id2= Areas[temp_id2]->parent;
        }
    }
    else {

        for(auto j=0;j<-1*depth_difference;++j){
                temp_id1= Areas[temp_id1]->parent;
        }
    }
    while (Areas[temp_id1]->parent != -1){

        if(Areas[temp_id1]->parent == Areas[temp_id2]->parent){
            return Areas[temp_id1]->parent;
        }
        temp_id1 = Areas[temp_id1]->parent;
        temp_id2 = Areas[temp_id2]->parent;


    }
    return NO_AREA;
}

std::vector<AreaID> Datastructures::recursionFunction(PlaceID id, std::vector<AreaID> &returnvector){
    if (Areas[id]->children.size() == 0){
        return returnvector;
    }
    for (auto child:Areas[id]->children){
        returnvector.push_back(child);
        recursionFunction(child, returnvector);
    }
    return returnvector;


}
