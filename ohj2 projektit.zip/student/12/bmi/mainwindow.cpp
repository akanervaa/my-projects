#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_countButton_clicked()
{   cout << pow(2.0,10)<<endl;
    float index = ui->weightLineEdit->text().toFloat()/pow((ui->heightLineEdit->text().toFloat()/100),2.0);
    ui->resultLabel->setText(QString::number(index));
    if(18.5 <= index && index <= 25){
        ui->infoTextBrowser->setText("Your weight is normal.");
    }
    else if(index < 18.5){
        ui->infoTextBrowser->setText("You are underweight.");
    }
    else {
        ui->infoTextBrowser->setText("You are overweight.");
    }
}
