#include "swap.hh"

// TODO: Implement swap function here
void swap(int &luku1, int &luku2){
   int vaihto1 = luku1;
   luku1 = luku2;
   luku2 = vaihto1;
}


