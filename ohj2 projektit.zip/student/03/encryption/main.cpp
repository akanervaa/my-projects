#include <iostream>
#include <cctype>
#include <cstring>
#include <algorithm>
using namespace std;
int virhetarkastin(string avain,string aakkoset){

    if(avain.length() != 26){
    cout << "Error! The encryption key must contain 26 characters."<<endl;
    return 0;}
    for(size_t i = 0; i < avain.length(); ++i)
        if(islower(avain[i])== false){
    cout <<"Error! The encryption key must contain only lower case characters."<<endl;
    return 0;}
    else
    for(size_t i= 0;i < aakkoset.length();++i){int count=0;
        for(size_t j= 0;j<avain.length();++j){
        if (avain[j] == aakkoset[i]) ++count;}
        if (count ==0){
        cout <<"Error! The encryption key must contain all alphabets a-z."<<endl;
        return 0;}}

    return 1;
}

int main()
{ string avain= "tyhjä";
  string salattava = "tyhjä";
  string aakkoset = "abcdefghijklmnopqrstuvwxyz";

cout << "Enter the encryption key: ";
cin >> avain;
if (virhetarkastin(avain,aakkoset)== 0)
    return EXIT_FAILURE;
cout <<"Enter the text to be encrypted: ";
cin >> salattava;
for(string::size_type i = 0; i < salattava.size(); ++i){
    if(islower(salattava[i])== false){
    cout <<"Error! The encryption key must contain only lower case characters."<<endl;
    return 0;}}
for (size_t j = 0; j < salattava.length(); j++)
{
    for (size_t i = 0; i < aakkoset.length(); i++)
    {
        if (aakkoset[i] == salattava[j])
        {
            salattava[j] = avain[i];
            break;
        }
    }
}
    cout << "Encrypted text: "<<salattava <<endl;}



