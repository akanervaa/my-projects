#include <iostream>
using namespace std;
// Write here a function counting the mean value

int main(){ 
    cout << "From how many integer numbers you want to count the mean value? ";
    int arvojen_lkm = 0;
    int summa = 0;
    int luku = 0;
    cin >> arvojen_lkm;
    if(arvojen_lkm<= 0){
        cout << "Cannot count mean value from " << arvojen_lkm <<" numbers" << endl;
        return 0;}
    int alkuarvo = 1;
    for(;alkuarvo<=arvojen_lkm;++alkuarvo){
        cout << "Input "<<alkuarvo <<". number: ";
        cin >> luku;
        summa += luku;}
    float keskiarvo = float(summa)/float(arvojen_lkm);
    cout << "Mean value of the given numbers is " << keskiarvo << endl;




}
