#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;


int main()
{   map<string,int>kilpailijat;
    string tiedoston_nimi = "";
    cout << "Input file: ";
    getline(cin, tiedoston_nimi);
    ifstream tiedosto_olio(tiedoston_nimi);
    if (not tiedosto_olio){cout << "Error! The file " << tiedoston_nimi << " cannot be opened."<<endl;
        return EXIT_FAILURE;
        }
    else{
        string rivi;
        string nimi;
        int pisteet;
        while ( getline(tiedosto_olio, rivi) ) {
        nimi = rivi.substr(0,rivi.find(":"));
        if(kilpailijat.find(nimi) != kilpailijat.end()){
            rivi.erase(0, rivi.find(":")+1 );
            kilpailijat.at(nimi) += stoi(rivi);
            }
        else{
        rivi.erase(0, rivi.find(":")+1 );
        pisteet = stoi(rivi);
        kilpailijat.insert({ nimi,pisteet } );
        }}
    cout << "Final scores:" <<endl;
    for (auto tietopari : kilpailijat)
        cout << tietopari.first <<": " << tietopari.second <<endl;
}
    return EXIT_SUCCESS;
}
