#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

int main()
{

string out_tiedosto = "";
string tiedosto = "";
cout << "Input file: ";
getline(cin, tiedosto);
cout << "Output file: ";
getline(cin, out_tiedosto);
ifstream tiedosto_olio(tiedosto);
    if ( not tiedosto_olio ) {
        cout << "Error! The file "<< tiedosto <<" cannot be opened." << endl;
        return EXIT_FAILURE;
    } else {
        string rivi;
        int i = 1;
        ofstream tiedosto_olio1(out_tiedosto);
        while ( getline(tiedosto_olio, rivi) ) {
           tiedosto_olio1 << to_string(i)<<" "<<rivi<<endl;
           ++ i;

        }
        tiedosto_olio.close();
}}
