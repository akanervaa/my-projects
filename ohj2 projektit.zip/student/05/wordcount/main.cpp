#include <iostream>
#include <string>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <vector>
#include <iterator>
using namespace std;

int main()
{
 string tiedoston_nimi = "";
 cout << "Input file: ";
 getline(cin,tiedoston_nimi);
 ifstream tiedosto_olio(tiedoston_nimi);
 if (not tiedosto_olio){
     cout << "Error! The file " <<tiedoston_nimi<< " cannot be opened." <<endl;
     return EXIT_FAILURE;
 }
 else {
     string rivi = "";
     string sana = "";
     int rivin_numero = 1;
     vector<int> lista = {};
     map<string,vector<int>> sanat;
     while(getline(tiedosto_olio,rivi)){
        sana = rivi.substr(0,rivi.find(":"));
        if (sanat.find(sana)!=sanat.end()){
            sanat.at(sana).push_back(rivin_numero);
        }
        else {
            sanat.insert({sana,lista});
            sanat.at(sana).push_back(rivin_numero);
        }
     rivin_numero ++;
     }

 for (auto tietopari : sanat){
     cout << tietopari.first << " "<< tietopari.second.size()<<": ";
     for (int alkio : tietopari.second){
         if (tietopari.second.size() != 1 and alkio != tietopari.second.back())
            cout << alkio <<", ";
        else
             cout << alkio;}
     cout << endl;
            }

    }
 return EXIT_SUCCESS;
}
