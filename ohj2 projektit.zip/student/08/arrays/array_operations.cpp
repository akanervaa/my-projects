#include "array_operations.hh"
int greatest_v1(int *itemptr, int size){
    int* taulukko_osoitin = nullptr;
    taulukko_osoitin = itemptr;
    int arvo = 0;
    while (taulukko_osoitin < itemptr + size){
        if (*taulukko_osoitin > arvo){
            arvo = *taulukko_osoitin;
        }
        taulukko_osoitin++;
    }
    return arvo;
}
int greatest_v2(int *itemptr, int *endptr){
    int* taulukko_osoitin = nullptr;
    taulukko_osoitin = itemptr;
    int arvo = 0;
    while (taulukko_osoitin < endptr){
        if (*taulukko_osoitin > arvo){
            arvo = *taulukko_osoitin;
        }
        taulukko_osoitin++;
    }
    return arvo;
}
void copy(int *itemptr, int *endptr, int *targetptr){
    int* taulukko_osoitin = nullptr;
    taulukko_osoitin = itemptr;
    while (taulukko_osoitin < endptr){
        *targetptr = *taulukko_osoitin;
        taulukko_osoitin++;
        targetptr++;
    }
}
void reverse(int *leftptr, int *rightptr){
    int* taulukko_osoitin = nullptr;
    taulukko_osoitin = rightptr-1;
    int arvo;
    int i = 0;
    while(taulukko_osoitin > leftptr+i){
        arvo = *(taulukko_osoitin);
        *taulukko_osoitin = *(leftptr+i);
        *(leftptr+i) = arvo;
        i++;
        taulukko_osoitin--;
    }
}
