#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int array[80];
    cout << "Input an expression in reverse Polish notation (end with #):"<<endl;
    cout << "EXPR> ";
    string s;
    int vastaus = 1;
    int* a;
    a = array;
    getline(cin,s);
    for (char merkki:s){
        if( merkki != ' '){
            if(merkki == '1'||merkki =='2' ||merkki =='3' ||merkki =='4'||merkki =='5' ||merkki =='6' ||merkki =='7' ||merkki =='8' ||merkki =='9' ||merkki =='0'){
                *(a+1) = int(merkki-48);
                a++;
            }
            else if(merkki == '*'||merkki == '+'||merkki == '-'||merkki == '/'){
                if (a == array){
                    cout << "Error: Expression must start with a number"<<endl;
                    return EXIT_FAILURE;
                }
                else if (merkki == '+'){
                    vastaus = *a + *(a-1);
                    a = a - 1;
                    *(a) = vastaus;
                }
                else if (merkki == '*'){
                    vastaus = *a * *(a-1);
                    a = a - 1;
                    *(a) = vastaus;
                }
                else if (merkki == '/'){
                    if (*a != 0){
                        vastaus =   *(a-1)/ *a;
                        a = a - 1;
                        *(a) = vastaus;
                    }
                    else {
                        cout << "Error: Division by zero" <<endl;
                        return EXIT_FAILURE;
                    }
                }
                else if (merkki == '-'){
                    vastaus = *(a-1) - *a;
                    a = a - 1;
                    *(a) = vastaus;
                }
            }
            else if(merkki == '#'){
                if (a == array + 1)
                    cout <<"Correct: " << vastaus << " is the result" <<endl;
                else if (a > array + 1){
                    cout << "Error: Too few operators" <<endl;
                    return EXIT_FAILURE;
                }
                else {
                    cout << "Error: Too few operands" <<endl;
                    return EXIT_FAILURE;
                }
            }
            else {
               if (a == array){
                    cout << "Error: Expression must start with a number"<<endl;
                    return EXIT_FAILURE;
               }
               else {
               cout <<"Error: Unknown character" <<endl;
               return EXIT_FAILURE;
               }
            }
        }
    }
    return EXIT_SUCCESS;
}
