﻿/* Numbers ( or 2048, but that's an invalid name ) : Template code
 *
 * Desc:
 *  This program generates a game of 2048, a tile combining game
 * where the goal is to get from 2's to 2048. The board is SIZE x SIZE,
 * ( original was 4x4 ) and every round the player chooses a direction
 * to which the tiles should fall. If they collide with a wall or a different
 * value, they will move as close as they can get. If they collide with
 * a tile with same value, they will combine and double the value. The
 * tile will continue to move until a wall or other tile comes along, but a
 * single tile can only be combined once per "turn".
 *  Game will end when the goal value asked (orig 2048) is reached or new
 * tile can't be added to the board.
 *
 * Program author ( Fill with your own info )
 * Name: Alex Kanerva
 * Student number: 285957
 * UserID: kanervaa ( Necessary due to gitlab folder naming. )
 * E-Mail: Alex.Kanerva@tuni.fi
 *
 * Notes about the program and it's implementation:
 * Valitettavasti en saanut toimimaan täysin oikein, muutenkin työläs projekti, mutta se on ymmärrettävää.
 */

#include "numbertile.hh"
#include <iostream>
#include <vector>
#include <random>
#include <string>
#include <algorithm>

const int SIZE = 4;
const int NEW_VALUE = 2;
const int PRINT_WIDTH = 5;
const int DEFAULT_GOAL = 2048;

using namespace std;
// Adds a single new value to board using rEng and distr for random positioning.
void newValue(std::vector<std::vector<NumberTile>> &board,
               std::default_random_engine &rEng,
               std::uniform_int_distribution<int> &distr){
    // Tries to assign NEW_VAl to randomly selected tile. Continues trying until
    // newVal() returns true.
    while(!board.at(distr(rEng)).at(distr(rEng)).setValue(NEW_VALUE));
}

// Initializes the board to size SIZE x SIZE and adds SIZE tiles with NEW_VALUE
// to it through new_value() func after initializing the random engine with
// a seed value.
void initBoard(std::vector<std::vector<NumberTile>> &board,
                std::default_random_engine &rEng,
                std::uniform_int_distribution<int> &distr){

    // Initialize the board with SIZE x SIZE empty numbertiles.
    for ( auto y = 0; y < SIZE; y++ ){
        board.push_back({});
        for ( auto x = 0; x < SIZE; x++ ){
            // If you don't want to use pairs, replace "std::make_pair(y, x)"
            // with "y, x".
            board.at(y).push_back(NumberTile(0));
        }

    }

    // Ask user for the seed value and initialize rEng.
    std::cout << "Give a seed value or an empty line: ";
    std::string seed = "";
    getline(std::cin, seed);

    if(seed == "") {
        // If the user did not give a seed value, use computer time as the seed
        // value.
        rEng.seed(time(NULL));
    } else {
        // If the user gave a seed value, use it.
        rEng.seed(stoi(seed));
    }

    // Add some tiles to the board.
    for ( int i = 0 ; i < SIZE ; ++i ){
        newValue(board, rEng, distr);
    }

}

// Prints the board.
void print(std::vector<std::vector<NumberTile>> &board){
    // The y isn't actually the y coordinate or some int, but an iterator that
    // is like a vector of NumberTiles.
    for ( auto y : board ){
        // Prints a row of dashes.
        std::cout << std::string(PRINT_WIDTH * SIZE + 1, '-') << std::endl;
        // And then print all cells in the desired width.
        for ( auto x : y ){
            x.print(PRINT_WIDTH);
        }
        // And a line after each row.
        std::cout << "|" << std::endl;
    }
    // Print a last row of dashes so that the board looks complete.
    std::cout << std::string(PRINT_WIDTH * SIZE + 1, '-') << std::endl;
}
bool moveTiles(string command,std::vector<std::vector<NumberTile>> &board,int goal,std::default_random_engine &rEng,
               std::uniform_int_distribution<int> &distr){
    // eri komentoihin reagoiminen.
    // ohjelma ei toimi täysin samalla tavalla kuin alkuperäinen 2048, kun liikkeet ovat toteutettu näin, esim jos rivillä on 0,4,4,8 tuossa järjestyksessä
    // "a"=vasemmalle,"d"=oikealle,"w" ylös ja "s" alas, kuten syytä olettaa.
    if (command == "d"){

        for ( auto y = 0; y < SIZE; y++ ){

            for ( auto x = SIZE-2; x >= 0; x-- ){

                if (board.at(y).at(x).getValue() > 0){

                    int index = x;
                    while(index < SIZE - 1){

                        if(board.at(y).at(index+1).getValue() == 0){

                            board.at(y).at(index+1).changeValue(board.at(y).at(index).getValue());
                            board.at(y).at(index).changeValue(0);
                            }
                        else if (board.at(y).at(index+1).getValue()==board.at(y).at(index).getValue()){

                                int tile_sum = board.at(y).at(index).getValue() * 2;
                                board.at(y).at(index+1).changeValue(tile_sum);
                                board.at(y).at(index).changeValue(0);
                                if (tile_sum == goal){
                                    return false;
                                }
                                break;
                            }
                        index ++;
                        }
                    }
                }
            }
        }
    else if (command == "a"){

        for ( auto y = 0; y < SIZE; y++ ){

            for ( auto x = 0; x < SIZE; x++ ){

                if (board.at(y).at(x).getValue() > 0){

                    int index = x;
                    while(index > 0){

                        if(board.at(y).at(index-1).getValue() == 0){

                            board.at(y).at(index-1).changeValue(board.at(y).at(index).getValue());
                            board.at(y).at(index).changeValue(0);
                            }
                        else if (board.at(y).at(index-1).getValue()==board.at(y).at(index).getValue()){

                                int tile_sum = board.at(y).at(index).getValue() * 2;
                                board.at(y).at(index-1).changeValue(tile_sum);
                                board.at(y).at(index).changeValue(0);
                                if (tile_sum == goal){
                                    return false;
                                    }
                                break;

                            }
                        index --;
                        }
                    }
                }
            }
        }
    else if (command == "w"){

        for ( auto x = 0; x < SIZE; x++ ){

            for ( auto y = 0; y < SIZE; y++ ){

                if (board.at(y).at(x).getValue() > 0){

                    int index = y;
                    while(index > 0){

                        if(board.at(index-1).at(x).getValue() == 0){

                            board.at(index-1).at(x).changeValue(board.at(index).at(x).getValue());
                            board.at(index).at(x).changeValue(0);
                            }
                            else if (board.at(index-1).at(x).getValue()==board.at(index).at(x).getValue()){

                                int tile_sum = board.at(index).at(x).getValue() * 2;
                                board.at(index-1).at(x).changeValue(tile_sum);
                                board.at(index).at(x).changeValue(0);
                                if (tile_sum == goal){
                                    return false;
                                    }
                                break;
                            }
                            index --;
                            }
                        }
                    }
                }
            }
    else if (command == "s"){

            }
    else if (command == "q"){
        return false;}
    newValue(board,rEng,distr);
    return true;
    }



void slide(std::vector<std::vector<NumberTile>> &board, int direction){
    sort(board.at(direction).begin()->getValue(),board.at(direction).end()->getValue());
}

int main()
{
    // Declare the board and randomengine.
    std::vector<std::vector<NumberTile>> board;
    std::default_random_engine randomEng;
    // And initialize the disrt to give numbers from the correct
    std::uniform_int_distribution<int> distr(0, SIZE - 1);
    initBoard(board, randomEng, distr);
    // Asks user for the goal number, default 2048
    string goal = "";
    cout << "Give a goal value or an empty line: ";
    getline(cin,goal);
    if(goal== ""){
        goal = to_string(DEFAULT_GOAL);
        }
    try {stoi(goal);
        }
    catch (invalid_argument&) { goal = to_string(DEFAULT_GOAL);
    }
    print(board);
    string command = "";
    cout << "Dir> ";
    cin >> command;
    slide(board, 2);
    // Mielestäni tälläinen järjestely ruudukon päivittämiseen on ihan hyvä, moveTiles totuusarvona siis false silloin, kun käyttäjä haluaa lopettaa käskyllä q tai voittaa pelin.
    while (moveTiles(command,board,stoi(goal),randomEng,distr)){
            if (command == "w" or command == "s" or command == "a" or command == "d"){
                print(board);
                cout << "Dir> ";
                cin >> command;}
            // Tätä en millään saanut toimimaan, kun command oli luokkaa character, sillä se kävi while loopissa jokaisen merkin erikseen... stringillä ei ongelmia.
                else{
                    cout << "Unknown command. "<<endl;
                    cout << "Dir> ";
                    cin >> command;
                }
           }
    //ehtolause jotta lopetuskomennolla tulostusta ei tule.
    if (command != "q"){
    print(board);
    cout << "You reached the goal value of "<<goal<< "!" <<endl;
    }
}
