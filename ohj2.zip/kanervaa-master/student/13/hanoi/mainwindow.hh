//student info: Alex Kanerva, alex.kanerva@tuni.fi,285957
#ifndef MAINWINDOW_HH
#define MAINWINDOW_HH

#include <QMainWindow>
#include <QApplication>
#include <QGraphicsEllipseItem>
#include <QGraphicsScene>
#include <QTimer>
#include <QGraphicsRectItem>
#include <vector>
#include <QDebug>
#include <QSize>
#include <string>
#include <cmath>
#include <QKeyEvent>

using namespace std;
using diskvector =vector<QGraphicsRectItem*>;
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    // This is for the key_press.
    void keyPressEvent(QKeyEvent* event) override;

private slots:
    //slots for buttons
    void on_ButtonAtoB_clicked();

    void on_ButtonBtoA_clicked();

    void on_ButtonCtoA_clicked();

    void on_ButtonAtoC_clicked();

    void on_ButtonBtoC_clicked();

    void on_ButtonCtoB_clicked();

    void on_StartButton_clicked();
    //this function is for time to update every second.
    void update();


    
private:
    Ui::MainWindow *ui_;
    // Basically core function of the program, takes the move given as a parametre and sets values
    //for function func() accordingly.
    void disk_move(string move);
    // Updates the state of every button after every move. This function is also used, when
    // checking legitimacy of key presses. Takes every peg as a parametre, and also the sizes
    // of jumps in qreal value, these jumps are to the peg which wasn't touched,
    // for example, if the move is A->B untouched peg is C and jumpFrom is the jump from A to C
    // and jumpTo from B to C respectively.Parametre move is the same as in disk_move().
    void update_buttons(string &move,diskvector& fromPeg,
                        diskvector &toPeg,diskvector &untouchedPeg,qreal jumpTo,qreal jumpFrom);
    // Convenient help function for moving disks, used in function disk_move() in order to make
    // the code clearer by having less rows. fromPeg and toPeg are the same as in update_buttons,
    // color is for the disk color change, and jump is the distance between the destination and
    // current location in x-axis.
    void func(diskvector &fromPeg,diskvector &toPeg,QBrush &color,qreal &jump);

    QGraphicsScene* scene_;     // a surface for
    QGraphicsRectItem* peg_;   // drawing a peg
    QGraphicsRectItem* disk_; // drawing a disk
    vector<QGraphicsRectItem*> disksA_; //vector of all disks in A peg.
    vector<QGraphicsRectItem*> disksB_; //vector of all disks in B peg.
    vector<QGraphicsRectItem*> disksC_; //vector of all disks in C peg.
    QTimer* timer_;   // for continuous moving
    string key ="";
    int moves = 0; // amount of  moves made at the start of the game

    int bestTimeSeconds = 9999; // very high value default value for best time,
                            //so that "best time" is reached even in the first round.
    int bestTimeMinutes = 9999; //same as seconds.

    int secondsValue = 0;//timer value at start
    int minutesValue = 0;

    const int STEP=170;//distance between 2 pegs in X-axis, used to move disks.
    const int NUMBER_OF_DISKS = 3;//total number of disks.
    const int MIN_MOVES = pow(2,NUMBER_OF_DISKS)-1;

    const int BORDER_UP = 0;//for scene setup. Copied from circle_move example
                           //as it was allowed.
    const int BORDER_DOWN = 260;
    const int BORDER_LEFT = 0;
    const int BORDER_RIGHT = 680;

    const int DISK_HEIGHT = -(BORDER_DOWN-10)/NUMBER_OF_DISKS;
    const int pegWidth = 15;
    const int pegHeight = -250;

    long unsigned int pegBMaxSize = NUMBER_OF_DISKS;//for win conditions.
    long unsigned int pegCMaxSize = NUMBER_OF_DISKS;

    int DiskYOnScene = BORDER_DOWN;//both the size of the disk
    //and the location in the scene varies between every disk
    //so these are necesssary.
    int DiskXOnScene = (BORDER_RIGHT)/(4*2);

    int DiskWidth = BORDER_RIGHT/4;
    int PegAdiskCount = NUMBER_OF_DISKS;
    int PegBdiskCount = 0;
    int PegCdiskCount = 0;
    const int DISK_WIDTH_REDUCTION = (STEP/2)/NUMBER_OF_DISKS;
    //this is how much disk location moves in x-axis. for every
    // new disk.
};

#endif // MAINWINDOW_HH
