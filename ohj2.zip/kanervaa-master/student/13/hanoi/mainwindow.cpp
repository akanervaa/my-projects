#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui_(new Ui::MainWindow)
{
    ui_->setupUi(this);
    scene_ = new QGraphicsScene(this);
    // these are copied from moving_circle example.
    /*
    // The graphicsView object is placed on the window
    // at the following coordinates:
    */
    int left_margin = 10; // x coordinate
    int top_margin = 270; // y coordinate
    // The width of the graphicsView is BORDER_RIGHT added by 2,
    // since the borders take one pixel on each side
    // (1 on the left, and 1 on the right).
    // Similarly, the height of the graphicsView is BORDER_DOWN added by 2.

    ui_->graphicsView->setGeometry(left_margin, top_margin,
                                   BORDER_RIGHT + 2, BORDER_DOWN + 2);
    ui_->graphicsView->setScene(scene_);
    /*
    // The width of the scene_ is BORDER_RIGHT decreased by 1 and
    // the height of it is BORDER_DOWN decreased by 1,
    // because the circle is considered to be inside the sceneRect,
    // if its upper left corner is inside the sceneRect.
    */
    scene_->setSceneRect(0, 0, BORDER_RIGHT - 1, BORDER_DOWN - 1);

    // Defining the color and outline of the circle
    QBrush redBrush(Qt::red);
    QPen blackPen(Qt::black);
    QBrush blueBrush(Qt::blue);
    blackPen.setWidth(2);
    // initializing the game
    peg_ = scene_->addRect(3*BORDER_RIGHT/4-pegWidth/2,260,
                           pegWidth,pegHeight, blackPen, Qt::yellow);

    peg_ = scene_->addRect(BORDER_RIGHT/2-pegWidth/2,260,
                           pegWidth,pegHeight, blackPen, Qt::red);

    peg_ = scene_->addRect(BORDER_RIGHT/4-pegWidth/2,260,
                           pegWidth,pegHeight, blackPen, Qt::blue);

    for(int i=0;i<NUMBER_OF_DISKS;++i){
        disk_ = scene_->addRect(0,0,DiskWidth,DISK_HEIGHT,blackPen,blueBrush);
        disk_->moveBy(DiskXOnScene,DiskYOnScene);
        disksA_.push_back(disk_);
        DiskYOnScene +=DISK_HEIGHT;
        DiskXOnScene +=DISK_WIDTH_REDUCTION;
        DiskWidth -= 2*DISK_WIDTH_REDUCTION;
    }
    ui_->MinMovesLabel->setText("Minimum moves to win: "
                                +QString::fromStdString(to_string(MIN_MOVES)));
    ui_->ButtonBtoA->setDisabled(true);
    ui_->ButtonBtoC->setDisabled(true);
    ui_->ButtonCtoA->setDisabled(true);
    ui_->ButtonCtoB->setDisabled(true);
    ui_->ButtonAtoB->setDisabled(true);
    ui_->ButtonAtoC->setDisabled(true);
    timer_ = new QTimer(this);
    timer_->setInterval(1000);
    connect(timer_,SIGNAL(timeout()),this,SLOT(update()));
}

MainWindow::~MainWindow()
{
    delete ui_;
    disksA_.clear();
    disksB_.clear();
    disksC_.clear();
    delete timer_;
}

void MainWindow::keyPressEvent(QKeyEvent* event)
{
    if(key == ""){
        if(event->key()== Qt::Key_A){
            key = "A";
            return;
            }
        else if(event->key()== Qt::Key_B){
            key = "B";
            return;
            }

        else if(event->key()== Qt::Key_C){
            key = "C";
            return;
            }
    }
    else if(event->key()== Qt::Key_B){
        if (key == "A"&&ui_->ButtonAtoB->isEnabled()){
            disk_move("A to B");
        }
        else if (key =="C"&&ui_->ButtonCtoB->isEnabled()){
            disk_move("C to B");
        }
        else {
            ui_->WinnerText->setText("Illegal move");
        }
            key = "";
    }
    else if(event->key()== Qt::Key_A){
        if (key == "B"&&ui_->ButtonBtoA->isEnabled()){
            disk_move("B to A");
        }
        else if (key =="C"&&ui_->ButtonCtoA->isEnabled()){
            disk_move("C to A");
        }
        else {
            ui_->WinnerText->setText("Illegal move");
        }
        key = "";
    }
    else if(event->key()== Qt::Key_C){
        if (key =="A"&&ui_->ButtonAtoC->isEnabled()){
            disk_move("A to C");
        }
        else if (key =="B"&&ui_->ButtonBtoC->isEnabled()){
            disk_move("B to C");
        }
        else {
            ui_->WinnerText->setText("Illegal move");
        }
        key = "";
    }
    if (event->key()== Qt::Key_U){
        key ="";
    }
}

void MainWindow::update(){
    ui_->seconds->display(secondsValue);
    secondsValue++;
    if(secondsValue%60==0){
        secondsValue = 0;
        minutesValue++;
        ui_->minutes->display(minutesValue);
    }
}


void MainWindow::on_ButtonAtoB_clicked()
{
    disk_move("A to B");
}

void MainWindow::on_ButtonBtoA_clicked()
{
    disk_move("B to A");
}

void MainWindow::on_ButtonCtoA_clicked()
{
    disk_move("C to A");
}

void MainWindow::on_ButtonAtoC_clicked()
{
    disk_move("A to C");
}

void MainWindow::on_ButtonBtoC_clicked()
{
    disk_move("B to C");
}

void MainWindow::on_ButtonCtoB_clicked()
{
    disk_move("C to B");
}

void MainWindow::disk_move(string move)
{   ui_->WinnerText->setText("");
    moves++;
    ui_->MovesLabel->setText("Moves made: "
                             +QString::fromStdString(to_string(moves)));
    // Making the earlier text to disappear
    ui_->statusLabel->clear();
    qreal jump = 0;
    QBrush color = Qt::blue;

    if (move == "A to B"){
        jump = (STEP);
        color = Qt::red;
        func(disksA_,disksB_,color,jump);
        update_buttons(move,disksA_,disksB_,disksC_,jump,2*jump);
    }
    else if (move == "C to A"){
        jump = -(2*STEP);
        color = Qt::blue;
        func(disksC_,disksA_,color,jump);
        update_buttons(move,disksC_,disksA_,disksB_,-jump/2,jump/2);
    }
    else if (move == "C to B"){
        jump = -(STEP);
        color = Qt::red;
        func(disksC_,disksB_,color,jump);
        update_buttons(move,disksC_,disksB_,disksA_,jump,2*jump);
    }
    else if (move == "B to C"){

        jump = STEP;
        color = Qt::yellow;
        func(disksB_,disksC_,color,jump);
        update_buttons(move,disksB_,disksC_,disksA_,-2*jump,-jump);
    }
    else if (move == "B to A"){
       jump = -(STEP);
       color = Qt::blue;
       func(disksB_,disksA_,color,jump);
       update_buttons(move,disksB_,disksA_,disksC_,-2*jump,-jump);
    }
    else if (move == "A to C"){
       jump = 2*STEP;
       color = Qt::yellow;
       func(disksA_,disksC_,color,jump);
       update_buttons(move,disksA_,disksC_,disksB_,-jump/2,jump/2);
    }
    QString QMove = QString::fromStdString(move);
    ui_->movesBrowser->append(QMove);
    // Checks win condition.
    if (disksB_.size() == pegBMaxSize|| disksC_.size() == pegCMaxSize){
        timer_->stop();
        if (minutesValue*60+secondsValue<bestTimeMinutes*60+bestTimeSeconds){
            bestTimeMinutes = minutesValue;
            bestTimeSeconds = secondsValue;
            QString seconds = QString::fromStdString(to_string(bestTimeSeconds));
            QString minutes = QString::fromStdString(to_string(bestTimeMinutes));
            QString bestTime = "best time: "+minutes+" minutes and "+seconds+" seconds.";
            ui_->BestTimeLabel->setText(bestTime);
        }
        update();
        key = "";
        ui_->ButtonBtoA->setDisabled(true);
        ui_->ButtonBtoC->setDisabled(true);
        ui_->ButtonCtoA->setDisabled(true);
        ui_->ButtonCtoB->setDisabled(true);
        ui_->ButtonAtoB->setDisabled(true);
        ui_->ButtonAtoC->setDisabled(true);
        ui_->StartButton->setDisabled(false);
        ui_->WinnerText->setText("You've won!");
    }
    scene_->update();
}

void MainWindow::update_buttons(string &move,diskvector& fromPeg,
    diskvector &toPeg,diskvector&untouchedPeg,qreal jumpTo,qreal jumpFrom)

{   QPushButton* button = ui_->ButtonAtoB;
    QPushButton* otherButton = ui_->ButtonAtoB;
    QPushButton* anotherButton = ui_->ButtonAtoB;
    QPushButton* fourthButton = ui_->ButtonAtoB;
    QPushButton* fifthButton = ui_->ButtonAtoB;
    QPushButton* sixthButton = ui_->ButtonAtoC;

    if (move == "A to B"){
        button = ui_->ButtonAtoB;
        otherButton = ui_->ButtonBtoA;
        anotherButton = ui_->ButtonAtoC;
        fourthButton = ui_->ButtonCtoA;
        fifthButton = ui_->ButtonBtoC;
        sixthButton=ui_->ButtonCtoB;

    }
    else if (move == "B to A"){
        button = ui_->ButtonBtoA;
        otherButton = ui_->ButtonAtoB;
        anotherButton = ui_->ButtonBtoC;
        fourthButton = ui_->ButtonCtoB;
        fifthButton = ui_->ButtonAtoC;
        sixthButton = ui_->ButtonCtoA;
    }
    if (move == "A to C"){
        button = ui_->ButtonAtoC;
        otherButton = ui_->ButtonCtoA;
        anotherButton = ui_->ButtonAtoB;
        fourthButton = ui_->ButtonBtoA;
        fifthButton = ui_->ButtonCtoB;
        sixthButton = ui_->ButtonBtoC;
    }
    else if (move == "C to A"){
        button = ui_->ButtonCtoA;
        otherButton = ui_->ButtonAtoC;
        anotherButton = ui_->ButtonCtoB;
        fourthButton = ui_->ButtonBtoC;
        fifthButton = ui_->ButtonAtoB;
        sixthButton = ui_->ButtonBtoA;
    }
    if (move == "B to C"){
        button = ui_->ButtonBtoC;
        otherButton = ui_->ButtonCtoB;
        anotherButton = ui_->ButtonBtoA;
        fourthButton = ui_->ButtonAtoB;
        fifthButton = ui_->ButtonCtoA;
        sixthButton = ui_->ButtonAtoC;
    }
    else if (move == "C to B"){
        button = ui_->ButtonCtoB;
        otherButton = ui_->ButtonBtoC;
        anotherButton = ui_->ButtonCtoA;
        fourthButton = ui_->ButtonAtoC;
        fifthButton = ui_->ButtonBtoA;
        sixthButton = ui_->ButtonAtoB;
    }
    button->setDisabled(true);
    otherButton->setEnabled(true);
    if (untouchedPeg.empty()==false){
        if(toPeg.back()->x()+jumpTo<untouchedPeg.back()->x()){
            fifthButton->setDisabled(true);
            sixthButton->setDisabled(false);
        }
        else {
            fifthButton->setDisabled(false);
            sixthButton->setDisabled(true);
        }
        if (fromPeg.empty()){
            fourthButton->setDisabled(false);
        }
        else if(fromPeg.back()->x()+jumpFrom<untouchedPeg.back()->x()){
            anotherButton->setDisabled(true);
            fourthButton->setDisabled(false);
        }
        else {
            anotherButton->setDisabled(false);
            fourthButton->setDisabled(true);
            }
    }
    else {
        anotherButton->setDisabled(false);
        fifthButton->setDisabled(false);
    }
    if (fromPeg.empty()){
        anotherButton->setDisabled(true);
    }
}

void MainWindow::func(diskvector &fromPeg,
                      diskvector &toPeg,QBrush& color,qreal &jump)

{   fromPeg.back()->setBrush(color);
    if (toPeg.empty()){
        fromPeg.back()->moveBy(jump, BORDER_DOWN-fromPeg.back()->y());
        toPeg.push_back(fromPeg.back());
        fromPeg.erase(fromPeg.end()-1,fromPeg.end());
        }

    else {
        qreal deltaY = -fromPeg.back()->y() + toPeg.back()->y();
        fromPeg.back()->moveBy(jump,deltaY+DISK_HEIGHT);
        toPeg.push_back(fromPeg.back());
        fromPeg.erase(fromPeg.end()-1,fromPeg.end());
    }
}

void MainWindow::on_StartButton_clicked()
{
    ui_->StartButton->setDisabled(true);
    secondsValue = 0;
    minutesValue = 0;
    ui_->minutes->display(minutesValue);
    ui_->seconds->display(minutesValue);
    moves  = 0;
    ui_->MovesLabel->setText("Moves made: "
                             +QString::fromStdString(to_string(moves)));
    update();
    timer_->start();
    ui_->ButtonAtoB->setDisabled(false);
    ui_->ButtonAtoC->setDisabled(false);
    if (disksB_.size() == pegBMaxSize){

        for(QGraphicsRectItem* disk:disksB_){
            disk->moveBy(-STEP,0);
            disk->setBrush(Qt::blue);
            disksA_.push_back(disk);
            disksB_.erase(disksB_.end()-1,disksB_.end());
        }
    }
    else if (disksC_.size() == pegCMaxSize) {

        for(QGraphicsRectItem* disk:disksC_){
            disk->moveBy(-2*STEP,0);
            disk->setBrush(Qt::blue);
            disksA_.push_back(disk);
            disksC_.erase(disksC_.end()-1,disksC_.end());
        }
    }
    ui_->WinnerText->clear();
    ui_->movesBrowser->clear();
    scene_->update();
}



