#include <iostream>
using namespace std;
string virhetarkastelu(int arv,int tot){
    if(arv <= 0 or tot <= 0){
            cout << "The number of balls must be a positive number."<< endl;
    return "virhe";}
    else if(arv > tot)
{cout << "The maximum number of drawn balls is the total amount of balls. "<<endl;
    return "virhe";}
else
return "ei virhettä";}
unsigned long int factorial(int n)
{   unsigned long int fact = 1;
    for(int i = 1; i <=n; ++i)
        {
            fact *= i;
        }
    return fact;
}

 int todnak(int arv,int tot,int vaha){
    unsigned long int tulos = 0;
    return tulos = factorial(tot) / (factorial(vaha)*factorial(arv));

}


int main()
{   int tot_pal_lkm = 0;
    int arv_pal_lkm = 0;
    cout << "Enter the total number of lottery balls: ";
    cin >> tot_pal_lkm;
    cout << "Enter the number of drawn balls: ";
    cin >> arv_pal_lkm;
    int vah = tot_pal_lkm-arv_pal_lkm;
    string virhe = virhetarkastelu(arv_pal_lkm,tot_pal_lkm);
    if ( virhe == "virhe") return 0;
    cout << "The probability of guessing all "<< arv_pal_lkm <<" balls correctly is 1/" <<
            todnak(arv_pal_lkm,tot_pal_lkm,vah)<<endl;

}
