#include <iostream>

using namespace std;

int main()
{  float lampotila = 0;
    cout << "Enter a temperature: ";

    // Write your code here

    cin >> lampotila;
    float fahr_lampotila = lampotila * 1.8 + 32;
    float cels_lampotila = (lampotila - 32) / 1.8;
    cout << lampotila << " degrees Celsius is " << fahr_lampotila<< " degrees Fahrenheit " << endl;
    cout << lampotila << " degrees Fahrenheit is " << cels_lampotila << " degrees Celsius " << endl;
    return 0;
}
