#include <iostream>
using namespace std;

int main(){
    int loppuluku = 0;
    cout << "How many numbers would you like to have? ";
    cin >> loppuluku;
    for (int alkuluku= 1;alkuluku<=loppuluku;++alkuluku)
        {if(alkuluku % 3 == 0){
            if(alkuluku % 7 == 0){
            cout << "zip boing" <<endl;
            continue;}
            else
                {cout << "zip" << endl;
            continue;}}
        if(alkuluku % 7==0){
            cout << "boing" << endl;
        continue;}
        else
            cout << alkuluku <<endl;}

}
