#include <iostream>

using namespace std;

int main()
{   int kerrottava = 0;
    cout << "Enter a number: ";
    cin >> kerrottava;
    int tulos = kerrottava * kerrottava * kerrottava;
    if  (abs(kerrottava) > 1290) {
    cout << "Error! The cube of "<< kerrottava << " is not " << tulos <<"." <<endl;}
    else cout << "The cube of " << kerrottava << " is " << tulos << "." <<endl;

    return 0;
}
