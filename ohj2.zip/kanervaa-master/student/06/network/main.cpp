#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <list>
#include <algorithm>
using namespace std;

const std::string HELP_TEXT = "S = store id1 i2\n P = print id\n"
                              "C = count id\n D = depth id";


std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false){
    std::vector<std::string> result;
    std::string tmp = s;

    while(tmp.find(delimiter) != std::string::npos)
    {
        std::string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}

string print_rekursio(map<string,vector<string>> nimet, string nimi,string pisteet = ".."){
    if (nimet.find(nimi) != nimet.end()) {
        for(string listanimi:nimet.at(nimi)){
        cout << pisteet << listanimi <<endl;
        pisteet.append("..");
        pisteet = print_rekursio(nimet,listanimi,pisteet);
        }
    }
    else {
        return pisteet.substr(0, pisteet.size()-2);
    }
return pisteet.substr(0, pisteet.size()-2);
}
int count_rekursio(map<string,vector<string>> nimet, string nimi,int count = 0){
    if (nimet.find(nimi) != nimet.end()) {
        for(string listanimi:nimet.at(nimi)){
        count ++;
        count = count_rekursio(nimet,listanimi,count);
        }
    }
    else {
        return count;
    }
return count;
}
list<int> depth_rekursio(map<string,vector<string>> nimet, string nimi,list<int> syvyydet={},int count=1){
    if (nimet.find(nimi) != nimet.end()) {
        for(string listanimi:nimet.at(nimi)){
        syvyydet.push_back(count);
        count ++;
        syvyydet =depth_rekursio(nimet,listanimi,syvyydet,count);
        count = 1;
        }
    }
    else {
        return syvyydet;
    }
syvyydet.push_back(count);
return syvyydet;
}
int main()
{
    // TODO: Implement the datastructure here

    map<string,vector<string>> nimet;

    while(true){
        std::string line;
        std::cout << "> ";
        getline(std::cin, line);
        std::vector<std::string> parts = split(line, ' ', true);

        std::string command = parts.at(0);

        if(command == "S" or command == "s"){
            if(parts.size() != 3){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
            }
            std::string id1 = parts.at(1);
            std::string id2 = parts.at(2);

            // TODO: Implement the command here!
            if(nimet.find(id1) != nimet.end()){
                nimet.at(id1).push_back(id2);   
                }
            else nimet[id1] = {id2};


        } else if(command == "P" or command == "p"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
            }
            std::string id = parts.at(1);

            // TODO: Implement the command here!
            cout << id << endl;
            print_rekursio(nimet,id,"..");
        } else if(command == "C" or command == "c"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
            }
            std::string id = parts.at(1);

            // TODO: Implement the command here!
            cout << count_rekursio(nimet,id)<<endl;

        } else if(command == "D" or command == "d"){
            if(parts.size() != 2){
                std::cout << "Erroneous parameters!" << std::endl << HELP_TEXT;
            }
            std::string id = parts.at(1);

            // TODO: Implement the command here!
            list<int> lista = depth_rekursio(nimet,id);
            if (lista.size() > 1){
            auto i = max_element(lista.begin(),lista.end());
            cout << *i+1 <<endl;}
            else cout << 1 << endl;
        } else if(command == "Q" or command == "q"){
           return EXIT_SUCCESS;
        } else {
            std::cout << "Erroneous command!" << std::endl << HELP_TEXT;
        }
    }
}
