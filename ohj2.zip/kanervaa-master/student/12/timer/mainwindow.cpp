#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    timer = new QTimer(this);
    timer->setInterval(1000);
    connect(timer,SIGNAL(timeout()),this,SLOT(update()));



}

MainWindow::~MainWindow()
{
    delete ui;
    delete timer;
}

void MainWindow::on_startButton_clicked()
{   timer->start();
}



void MainWindow::update()
{
    ui->lcdNumberSec->display(seconds_value);
    seconds_value++;
    if(seconds_value%60==0){
        seconds_value = 0;
        minutes_value++;
        ui->lcdNumberMin->display(minutes_value);
    }


}

void MainWindow::on_stopButton_clicked()
{
    timer->stop();
}

void MainWindow::on_resetButton_clicked()
{
    seconds_value = 0;
    minutes_value = 0;
    ui->lcdNumberMin->display(minutes_value);
    ui->lcdNumberSec->display(seconds_value);
}
