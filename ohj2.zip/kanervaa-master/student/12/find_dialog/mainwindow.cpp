#include "mainwindow.hh"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_fileLineEdit_editingFinished()
{
    ifstream inFile;
    string teksti = (ui->fileLineEdit->text().toStdString());
    inFile.open(teksti);
    string rivi = "";
    QString str = "";
    if ( not inFile ) {
        str = QString::fromStdString("File not found");
        ui->textBrowser->setText(str);
    }
    else{
        str = QString::fromStdString("File found");
        ui->textBrowser->setText(str);
    }
}

void MainWindow::on_findPushButton_clicked()
{   ifstream inFile;
    string teksti = (ui->fileLineEdit->text().toStdString());
    string etsittava_sana = (ui->keyLineEdit->text().toStdString());
    inFile.open(teksti);
    QString str = "";
    string rivi = "";
    string lower_rivi ="";
    string lower_etsittava_sana="";
    while(getline(inFile,rivi)){
        rivi = " "+rivi+" ";
        lower_rivi.resize(rivi.length());
        std::transform(rivi.begin(), rivi.end(), lower_rivi.begin(),
            [](unsigned char c){ return std::tolower(c); });
        lower_etsittava_sana.resize(etsittava_sana.length());
        std::transform(etsittava_sana.begin(), etsittava_sana.end(), lower_etsittava_sana.begin(),
            [](unsigned char c){ return std::tolower(c); });
        if (etsittava_sana != ""||etsittava_sana.empty()==false){
            if(lower_rivi.find(" "+lower_etsittava_sana+" ") != string::npos&&ui->matchCheckBox->isChecked()==false){
                str = QString::fromStdString("Word found");
                ui->textBrowser->setText(str);
                break;
            }
            else if(rivi.find(" "+etsittava_sana+" ") != string::npos&&ui->matchCheckBox->isChecked()){
                str = QString::fromStdString("Word found");
                ui->textBrowser->setText(str);
                break;
            }
            else{
                str = QString::fromStdString("Word not found");
                ui->textBrowser->setText(str);

            }
        }
    }
}
