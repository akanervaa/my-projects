#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <cctype>
using namespace std;
/* Program author
* Name: Alex Kanerva
* Student number: 285957
* UserID: kanervaa
* E-Mail: Alex.Kanerva@tuni.fi
*
* Notes about the program and it's implementation:
* Jätin funktioiden sisäiset kommentit vähemmälle, sillä uskon, että toteutin
* funktiot sen verran selkeällä nimeämisellä/toteuksella, ettei niissä epäselvyyksiä.
* Näköjään vektoreita ei saisi indeksoida hakasulkeilla, mutta tähän ohjelmaan näin tein.
*/


// split funktio, joka splittaa parametristä delimiter (tässä ohjelmassa välilyönti), jos se ei ole lainausmerkkejen sisällä.
// parametri s on string,joka splitataan, ignore_emptyn totuusarvo kertoo, kuuluuko viimeisen splitin jälkeen oleva jälkimmäinen
// string lisätä listaan, jos arvo false, silloin kuuluu. Funktio palauttaa listan, jonka alkiot ovat s:stä splitattuja stringejä.
std::vector<std::string> split(const std::string& s, const char delimiter, bool ignore_empty = false){
    std::vector<std::string> result;
    std::string tmp = s;
    string new_part;

    while(tmp.find(delimiter) != std::string::npos)
    {
        if (tmp.at(0)== '\"'){
            tmp = tmp.substr(1, tmp.size());
            new_part = tmp.substr(0, tmp.find('\"'));
            if (tmp.back() != '\"'){
                tmp = tmp.substr(tmp.find('\"')+2, tmp.size());
            }
            else {
                tmp = tmp.substr(tmp.find('\"')+1, tmp.size());
            }
        }
        else {
            new_part = tmp.substr(0, tmp.find(delimiter));
            tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        }
        if(not (ignore_empty and new_part.empty()) ){
            result.push_back(new_part);
        }
    }

    if(not (ignore_empty and tmp.empty())){   
        result.push_back(tmp);
    }
    return result;
}
// The most magnificent function in this whole program.
// Prints a RASSE
void print_rasse()
{
    std::cout <<
                 "=====//==================//===\n"
                 "  __<<__________________<<__   \n"
                 " | ____ ____ ____ ____ ____ |  \n"
                 " | |  | |  | |  | |  | |  | |  \n"
                 " |_|__|_|__|_|__|_|__|_|__|_|  \n"
                 ".|                  RASSE   |. \n"
                 ":|__________________________|: \n"
                 "___(o)(o)___(o)(o)___(o)(o)____\n"
                 "-------------------------------" << std::endl;
}

// Lukee tiedoston ja palauttaa sen riveistä muodostuneen reitti-pysäkkilista mapin,
// joka on tämän ohjelman tietorakenne.
map<string,vector<string>> lue_tiedosto(){
    string tiedoston_nimi = "";
    cout <<"Give a name for input file: ";
    getline(cin,tiedoston_nimi);
    ifstream tiedosto(tiedoston_nimi);
    if (not tiedosto){
        cout <<"Error: File could not be read."<<endl;
        return {};
    }
    else {
        map<string,vector<string>> pysakit;
        string rivi;

        while ( getline(tiedosto, rivi) ) {
            vector<string> reittipysakki = split(rivi,';');
            if (reittipysakki.size() != 2){
                cout << "Error: Invalid format in file."<<endl;
                return {};
            }

            else {
                string reitti = reittipysakki[0];
                string pysakki = reittipysakki[1];
                if(pysakit.find(reitti) != pysakit.end()){
                    if (find(pysakit.at(reitti).begin(),pysakit.at(reitti).end(),pysakki) == pysakit.at(reitti).end()){
                        pysakit.at(reitti).push_back(pysakki);
                    }
                    else {
                        cout << "Error: Station/line already exists."<<endl;
                        return {};
                    }
                }
                else {
                    pysakit[reitti] = {pysakki};
                }
            }
         }
        return pysakit;
    }
}
// Tulostaa kaikki tietorakenteesta löytyvät reitit, parametrinä tietenkin tietorakenne,
// jotta siihen kuuluvat reitit voidaan tulostaa.
void print_reitit(map <string,vector<string>> luettelo){
    cout <<"All tramlines in alphabetical order:"<<endl;
    map <string,vector<string>>::iterator iter= luettelo.begin();

    while(iter!=luettelo.end()){
        cout <<iter->first<<endl;
        ++iter;
    }

}

// Tulostaa annetun reitin kaikki pysäkit, parametreinä reitti sekä tietorakenne, jotta reitin pysäkkien
// tulostaminen funktiossa olisi mahdollista.
void print_reitin_pysakit(map <string,vector<string>> luettelo,string reitti){
    if (luettelo.find(reitti) ==luettelo.end()){
        cout <<  "Error: Line could not be found."<<endl;
    }
    else{
        cout <<"Line " <<reitti<< " goes through these stations in the order they are listed:"<<endl;

        for(string eka:luettelo.at(reitti)){
            cout <<" - "<< eka <<endl;

        }
    }
}

// Tulostaa kaikki tietorakenteesta löytyvät pysäkit, parametrinä tietenkin tietorakenne,
// jotta siihen kuuluvat pysäkit voidaan tulostaa.
void print_pysakit(map<string,vector<string>>luettelo){
    vector<string> pysakit;
    for (map<string,vector<string>>::iterator it = luettelo.begin();  it!= luettelo.end(); ++it){
        vector<string> v = it->second;

        for (string pysakki:v){
            if (find(pysakit.begin(),pysakit.end(),pysakki) == pysakit.end()){
                pysakit.push_back(pysakki);
            }
        }

    }

    sort(pysakit.begin(),pysakit.end(),less<string>());
    cout <<"All stations in alphabetical order:"<<endl;
    for(string pysakki:pysakit){
        cout << pysakki <<endl;

    }
}

// Tulostaa kaikki reitit, joissa annettu pysäkki on pysäkkinä. Parametreinä tietorakenne,
// ja pysäkki, jotta tulostukset funktiossa mahdollisia.
void print_pysakin_reitit(map<string,vector<string>>luettelo,string pysakki){
    vector<string>reitit;

    for (map<string,vector<string>>::iterator it = luettelo.begin();  it!= luettelo.end(); ++it){
        string reitti = it->first;
        if(find(luettelo.at(reitti).begin(),luettelo.at(reitti).end(),pysakki) != luettelo.at(reitti).end() ){
            if(find(reitit.begin(),reitit.end(),reitti) == reitit.end() ){
                reitit.push_back(reitti);
            }
        }   
    }

    if (reitit.size()== 0){
        cout << "Error: Station could not be found." <<endl;
    }
    else {
        cout << "Station " << pysakki << " can be found on the following lines:"<<endl;
        sort(reitit.begin(),reitit.end(),less<string>());

        for(string reitti:reitit){
                cout << " - "<<reitti <<endl;

        }
    }

}

// Lisää tietorakenteeseen uuden reitin. Parametreinä viite tietorakenteeseen, jotta siihen
// tehdyt muokkaukset näkyvät funktion ulkopuolella, sekä lisättäv reitti.
void lisaa_reitti(map<string,vector<string>> &luettelo,string reitti){
    if (luettelo.find(reitti) != luettelo.end()){
        cout << "Error: Station/line already exists."<<endl;
    }
    else {
        luettelo[reitti] = {};
        cout << "Line was added." <<endl;
    }
}

// Lisää reittiin uuden pysäkin, jos reitti löytyy tietorakenteesta. Pysäkki lisätään reitin viimeiseksi,
// jos sen jälkeistä pysäkkiä ei ole parametreissä annettu. Parametreinä viittaus tietorakenteeseen, muokattava reitti,
// lisättävä pysäkki, ja sen jälkeinen pysäkki, jos se on annettu (parametrissä oletusarvo, jotta voidaan tarkastaa, onko tämä pysäkki annettu).
void lisaa_pysakki(map<string,vector<string>> &luettelo,string reitti,string uusi_pysakki,string seuraava_pysakki=""){
    if (luettelo.find(reitti) ==luettelo.end()){
        cout <<  "Error: Line could not be found."<<endl;
    }
    else if (find(luettelo.at(reitti).begin(),luettelo.at(reitti).end(),uusi_pysakki) != luettelo.at(reitti).end()){
        cout << "Error: Station/line already exists."<<endl;
    }
    else  {
        if (seuraava_pysakki !=""){
        luettelo.at(reitti).insert(find(luettelo.at(reitti).begin(),luettelo.at(reitti).end(),seuraava_pysakki),uusi_pysakki);
        }
        else {
             luettelo.at(reitti).push_back(uusi_pysakki);
        }
        cout <<"Station was added."<<endl;
    }
}

// Tarkastaa, onko komento virheellinen. Parametrinä komento, jota
// tarkastetaan.
bool virhe_tarkastelu(vector<string> komento){
    if (komento.size()==1){
        cout <<"Error: Invalid input."<<endl;
        return false;
    }
    else return true;
}

// Poistaa annetun pysäkin kaikilta tietorakenteeseen lisätyistä reiteistä.
// parametreinä viite tietorakenteeseen, sekä poistettava pysäkki.
void poista_pysakki(map<string,vector<string>> &luettelo, string pysakki){
    string reitti;
    int count = 0;
    for (map<string,vector<string>>::iterator it = luettelo.begin();  it!= luettelo.end(); ++it){
        vector<string>& pysakit = it->second;
        reitti = it->first;
        if(find(pysakit.begin(),pysakit.end(),pysakki) != pysakit.end() ){
            pysakit.erase(find(pysakit.begin(),pysakit.end(),pysakki) );
            count++;
        }
    }
    if (count ==0){
        cout <<"Error: Station could not be found."<<endl;
    }
    else{
    cout <<"Station was removed from all lines."<<endl;
    }
}

// main funktio, jossa ohjelman suoritus ja kaikki funktiokutsut tapahtuvat.
int main()
{
    print_rasse();
    map <string,vector<string>> reitti_pysakki_luettelo = lue_tiedosto();
    if (reitti_pysakki_luettelo.empty()){
        return EXIT_FAILURE;
    }
    else {
        string command="";

        while(command != "QUIT"){
            cout <<"tramway> ";
            command.clear();
            getline(cin, command);
            vector<string> komennon_parametrit = split(command,' ');
            transform(komennon_parametrit[0].begin(), komennon_parametrit[0].end(), komennon_parametrit[0].begin(),[](unsigned char c){
                return toupper(c);
            });
            if (komennon_parametrit[0] == "LINES"){
            print_reitit(reitti_pysakki_luettelo);
            }

            else if (komennon_parametrit[0] == "LINE" ){
                if (virhe_tarkastelu(komennon_parametrit)){
                print_reitin_pysakit(reitti_pysakki_luettelo,komennon_parametrit[1]);
                }
            }

            else if (komennon_parametrit[0] == "STATIONS" ){
                print_pysakit(reitti_pysakki_luettelo);
            }

            else if (komennon_parametrit[0] == "STATION" ){
                if (virhe_tarkastelu(komennon_parametrit)){
                    print_pysakin_reitit(reitti_pysakki_luettelo,komennon_parametrit[1]);
               }
            }

            else if (komennon_parametrit[0]== "ADDLINE"){
                if (virhe_tarkastelu(komennon_parametrit)){
                lisaa_reitti(reitti_pysakki_luettelo,komennon_parametrit[1]);
                }
            }

            else if (komennon_parametrit[0] == "ADDSTATION"){
                if (komennon_parametrit.size() == 3 ){
                    lisaa_pysakki(reitti_pysakki_luettelo,komennon_parametrit[1],komennon_parametrit[2]);
                }
                else if (komennon_parametrit.size() == 4){
                    lisaa_pysakki(reitti_pysakki_luettelo,komennon_parametrit[1],komennon_parametrit[2],komennon_parametrit[3]);
                }
                    else {
                        cout << "Error: Invalid input."<<endl;
                    }
            }
            else if (komennon_parametrit[0]== "REMOVE"){
                if (virhe_tarkastelu(komennon_parametrit)){
                    poista_pysakki(reitti_pysakki_luettelo,komennon_parametrit[1]);
                }                
            }
            else if (komennon_parametrit[0]== "QUIT"){
                command = komennon_parametrit[0];
            }
            else {
                cout << "Error: Invalid input." <<endl;
            }
        }
    }
    return EXIT_SUCCESS;
}

