#include "loan.hh"

using namespace std;

Loan::Loan(const std::string& title,
           const std::string& loaner,
           Date*& loan_date
           ) :
    title_(title),
    loaner_(loaner),
    loan_due_date_(nullptr),
    is_due_(false),
    renewal_count_(0)

{
    loan_due_date_ = new Date(loan_date->getDay(),loan_date->getMonth(),loan_date->getYear());
    loan_due_date_->advance_by_loan_length();
}

Loan::~Loan()
{
    delete loan_due_date_;
}

string Loan::get_due_date(){
    return loan_due_date_->to_string();
}

string Loan::is_due()
{
    if (is_due_ == false){
        return "0";
    }
    else {
        return "1";
    }
}



string Loan::get_book() const
{
    return title_;
}

void Loan::renew_loan()
{
    if(renewal_count_<DEFAULT_RENEWAL_AMOUNT){
        loan_due_date_->advance_by_loan_length();
        renewal_count_++;
        cout << RENEWAL_SUCCESSFUL<< loan_due_date_->to_string()<<endl;
    }
    else {
        cout << OUT_OF_RENEWALS_ERROR<<endl;
    }
}

void Loan::check_due(Date *&date)
{
    if (loan_due_date_->getYear()*365+loan_due_date_->getMonth()*30+loan_due_date_->getDay() < date->getDay()+date->getMonth()*30+date->getYear()*365){
        is_due_ = true;
    }
    else {
        is_due_ = false;
    }
}

string Loan::get_loaner() const
{
    return loaner_;
}
