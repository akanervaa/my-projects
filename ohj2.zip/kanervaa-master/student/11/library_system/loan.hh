/* Module: Loan
 * ------------
 * This class and its bahaviour should be defined by the student.
 *
 * TIE-0220x S2019
 * */
#ifndef LOAN_HH
#define LOAN_HH
#include <string>
#include "book.hh"
#include "person.hh"
#include "date.hh"
#include "library.hh"

#include <iostream>
using namespace std;

const int DEFAULT_RENEWAL_AMOUNT = 6;

class Loan
{
public:
    //Has constructors for the title, name of the loaner,the due date of the loan,bool value of loan being due,renewal count for checking how many times book has been renewed.
    Loan(const std::string& title,
         const std::string& loaner,
         Date*& loan_date
         );
    // Is run when loan class is deleted, assures loan_due_date object is deleted.
    ~Loan();
    //return name of the loaner.
    std::string get_loaner() const;
    // Converts due_date into string
    std::string get_due_date();
    // returns 0 or 1 based on if loan is due.
    std::string is_due();
    //Returns the title of the loaned book.
    std::string get_book() const;
    //Renews the loan, I assume already due'd loan cannot be undue'd by renewing it (wasn't specified).
    void renew_loan();
    // Checks if a loan is due by comparing current date to loan due date. For some reason operator < in date class didn't work so I made one for myself.
    // Not perfectly accurate, but does the job.
    void check_due(Date*& date);
private:
    string title_;
    string loaner_;
    Date* loan_due_date_;
    bool is_due_;
    int renewal_count_;

};

#endif // LOAN_HH
