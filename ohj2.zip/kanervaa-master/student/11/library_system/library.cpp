#include "library.hh"
#include <iostream>

// Let's use the date when the project was published as the first date.
Library::Library():
    today_(new Date(13, 11, 2019)),
    books_({}),
    authors_({}),
    accounts_({}),
    loans_({})
{

}

Library::~Library()
{
    // Free all memory reserved with the keyword new.
    delete today_; today_ = nullptr;
    for ( std::pair<std::string, Book*> book : books_ ){
        delete book.second;
        book.second = nullptr;
    }
    for ( std::pair<std::string, Person*> author : authors_ ){
        delete author.second;
        author.second = nullptr;
    }
    for ( std::pair<std::string, Person*> account : accounts_ ){
        delete account.second;
        account.second = nullptr;
    }
    for ( std::pair<std::string, Loan*> loaner : loans_ ){
        delete loaner.second;
        loaner.second = nullptr;
    }
}

void Library::all_books()
{
    for ( std::pair<std::string, Book*> book : books_ ){
        std::cout << book.first << std::endl;
    }
}

void Library::all_books_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Book*> book : books_ ){
        book.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

void Library::all_borrowers()
{
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        std::cout << borrower.first << std::endl;
    }
}

void Library::all_borrowers_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        borrower.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

bool Library::add_book(const std::string &title, const std::vector<std::string> authors, const std::string &description, const std::set<std::string> genres)
{
    if ( authors.empty() ){
        std::cout << MISSING_AUTHOR_ERROR << std::endl;
        return false;
    }
    std::vector<Person*> author_ptrs;
    for ( std::string author : authors ){
        Person* n_person;
        if ( authors_.find(author) == authors_.end() ){
            n_person = new Person(author, "", "");
            authors_.insert({author, n_person});
        } else {
            n_person = authors_.at(author);
        }
        author_ptrs.push_back(n_person);
    }
    Book* n_book = new Book(title, author_ptrs, description, genres);
    books_.insert({title, n_book});
    return true;
}

void Library::add_borrower(const std::string &name, const std::string &email,
                           const std::string &address)
{
    if ( accounts_.find(name) != accounts_.end()){
        std::cout << DUPLICATE_PERSON_ERROR << std::endl;
        return;
    }

    Person* n_person = new Person(name, email, address);
    accounts_.insert({name, n_person});
}

void Library::set_date(int day, int month, int year)
{
    delete today_;
    today_ = new Date(day, month, year);
    today_->show();
    check_date(today_);
}

void Library::advance_date(int days)
{
    today_->advance_by(days);
    today_->show();
    check_date(today_);
}

void Library::loaned_books()
{
    if (loans_.empty())
        return;
    else {
        cout << LOAN_INFO <<endl;

        for(pair<string,Loan*> loaner:loans_){
            cout << loaner.first<< " : " <<loaner.second->get_loaner() <<" : "<<loaner.second->get_due_date()<<" : "<<loaner.second->is_due()<<endl;
        }

    }
}

void Library::loans_by(const std::string &borrower)
{
    if (accounts_.find(borrower) == accounts_.end()){
        cout << CANT_FIND_ACCOUNT_ERROR <<endl;
    }
    else{

        for(pair<string,Loan*>loans:loans_){
            if(loans.second->get_loaner()==borrower){
                cout << loans.second->get_book()<<" : "<<loans.second->get_due_date()<<" : "<<loans.second->is_due()<<endl;
            }

        }

    }
}

void Library::loan(const std::string &book_title, const std::string &borrower_id){
    if (accounts_.find(borrower_id)==accounts_.end()){
        cout << CANT_FIND_ACCOUNT_ERROR<<endl;
    }
    else if (books_.find(book_title)==books_.end()){
        cout << CANT_FIND_BOOK_ERROR<<endl;
    }
    else if (loans_.find(book_title) == loans_.end()){
        Loan* n_loan = new Loan(book_title,borrower_id,today_);
        loans_.insert({book_title, n_loan});
    }
    else {
        cout << ALREADY_LOANED_ERROR<<endl;
    }
}

void Library::renew_loan(const std::string &book_title)
{
    if (loans_.find(book_title)!=loans_.end()){
        loans_[book_title]->Loan::renew_loan();
    }
    else if (books_.find(book_title) ==books_.end()){
        cout << CANT_FIND_BOOK_ERROR <<endl;
    }
    else {
        cout << LOAN_NOT_FOUND_ERROR <<endl;
    }
}

void Library::return_loan(const std::string &book_title)
{
    if (loans_.find(book_title)!=loans_.end()){
        delete loans_.at(book_title);
        loans_.at(book_title) = nullptr;
        loans_.erase(book_title);
        cout << RETURN_SUCCESSFUL <<endl;
    }
    else if (books_.find(book_title) ==books_.end()){
        cout << CANT_FIND_BOOK_ERROR <<endl;
    }
    else {
        cout << LOAN_NOT_FOUND_ERROR <<endl;
    }
}

void Library::check_date(Date*& today)
{
    for(pair<string,Loan*> loan:loans_)
        loan.second->check_due(today);
}
