#include "cards.hh"
using namespace std;
// TODO: Implement the methods here
Cards::Cards(): top_(nullptr) {
}
Cards::~Cards() {
   while ( top_ != nullptr ) {
      Card_data* item_to_be_released = top_;
      top_ = top_->next;

      delete item_to_be_released;
   }
}
void Cards::add(int id){
    Card_data* new_card = new Card_data{id, nullptr};
    if ( top_ == nullptr ) {
       top_ = new_card;

    } else {
       Card_data* old_card = top_;
       top_ = new_card;
       top_->next = old_card;
    }
}
bool Cards::remove(int &id){
    if (top_ != nullptr) {
       Card_data* item_to_be_removed = top_;
       id = item_to_be_removed->data;
       top_ = top_->next;
       delete item_to_be_removed;
       return true;
    }
    else {
        return false;
    }
}
void Cards::print_from_top_to_bottom(std::ostream& s){

    Card_data* item_to_be_printed = top_;
    int running_number = 1;
    while ( item_to_be_printed != nullptr ) {
       s << running_number << ": "<< item_to_be_printed->data <<endl;
       ++running_number;
       item_to_be_printed = item_to_be_printed->next;
    }
}
bool Cards::top_to_bottom(){
    Card_data* item_in_bot = top_;
    while (item_in_bot->next != nullptr){
        item_in_bot = item_in_bot->next;
    }
    Card_data* item_in_top = new Card_data{top_->data,nullptr};
    if (top_!=nullptr){
    remove(top_->data);
        if (top_==nullptr){
        top_ = item_in_top;
        }
    item_in_bot->next = item_in_top;
    return true;
    }
    else
        return false;
}
bool Cards::bottom_to_top(){
    Card_data* item_in_bot = top_;
    while (item_in_bot->next != nullptr){
        item_in_bot = item_in_bot->next;
        }
    add (item_in_bot->data);
    item_in_bot = top_;
    while (item_in_bot->next->next != nullptr){
        item_in_bot = item_in_bot->next;
        }
    item_in_bot->next=nullptr;
    if (top_!=nullptr){
    return true;
    }
    else
        return false;
}
int Cards::recursive_print(Card_data* top, std::ostream& s,int &running_number){
    if (top->next == nullptr){
        s <<running_number<<": "<< top->data<<endl;
    }
       else {
        recursive_print(top->next,s,running_number);
        running_number++;
        s<<running_number<<": "<< top->data<<endl;
        }
    return 1;
}

void Cards::print_from_bottom_to_top(std::ostream& s){
    int running_number = 1;
    recursive_print(top_,s,running_number);
}
