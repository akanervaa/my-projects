#include "queue.hh"
#include <iostream>
using namespace std;
// Implement the member functions of Queue here
Queue::Queue(unsigned int cycle): first_(nullptr) ,last_(nullptr){
    cycle_ = cycle;
}
Queue::~Queue(){
}
void Queue::switch_light(){
    if(is_green_){
        is_green_ = false;
        print();
    }
    else {
        is_green_ = true;
        print();
        if(first_ != nullptr){
            for(unsigned int i=0;i<cycle_;++i){
                 dequeue();
            }
           is_green_ = false;
        }
    }
}
void Queue::enqueue(string reg){
    if (first_ == nullptr){
        if (is_green_ == true){
            cout <<"GREEN: The vehicle "<<reg<<" need not stop to wait"<<endl;
        }
        else {
            Vehicle* car = new Vehicle{reg,nullptr};
            first_ = car;
            last_ = car;
        }
    }
    else {
        Vehicle* car = new Vehicle{reg,nullptr};
        last_->next = car;
        last_ = car;
    }
}
void Queue::print(){
    string light = "";
    string status = "";
    if (is_green_){
        light = "GREEN";
        status = "can go on";
        }
    else {light = "RED";
        status = "waiting in traffic lights";
        }
    if(first_ != nullptr){
        Vehicle* reg_to_be_printed = first_;
        cout << light << ": Vehicle(s) ";
        if(is_green_){
        for(unsigned int i=0;i<cycle_;++i){
            cout << reg_to_be_printed->reg_num<<" ";
            reg_to_be_printed = reg_to_be_printed->next;
            if (reg_to_be_printed==nullptr)
                break;
        }
        }
        else{
            while(reg_to_be_printed!=nullptr){
                cout << reg_to_be_printed->reg_num<<" ";
                reg_to_be_printed = reg_to_be_printed->next;
            }
        }
        cout <<status <<endl;
    }
    else {
        cout << light << ": No vehicles waiting in traffic lights" <<endl;;
    }

}
void Queue::reset_cycle(unsigned int cycle){
    cycle_ = cycle;
}
void Queue::dequeue(){
    if (first_!=nullptr){
    Vehicle* car_to_be_removed= first_;
    first_ = first_->next;
    delete car_to_be_removed;
    }
}
