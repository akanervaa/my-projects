#include <iostream>


int main()
{
    std::cout << "How many numbers would you like to have? ";
}
