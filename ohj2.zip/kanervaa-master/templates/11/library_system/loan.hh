/* Module: Loan
 * ------------
 * This class and its bahaviour should be defined by the student.
 *
 * TIE-0220x S2019
 * */
#ifndef LOAN_HH
#define LOAN_HH

const int DEFAULT_RENEWAL_AMOUNT = 6;

class Loan
{
public:
    Loan();
    ~Loan();

private:

};

#endif // LOAN_HH
